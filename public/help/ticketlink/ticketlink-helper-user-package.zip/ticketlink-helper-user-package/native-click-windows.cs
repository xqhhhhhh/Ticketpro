using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

// Kept separate from the mouse INPUT structure so keyboard changes cannot
// change the existing mouse ABI. This union preserves sizeof(INPUT) on x86/x64.
public static class TicketlinkNativeKeyboard
{
    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort wVk, wScan;
        public uint dwFlags, time;
        public UIntPtr dwExtraInfo;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct MOUSEINPUT
    {
        public int dx, dy;
        public uint mouseData, dwFlags, time;
        public UIntPtr dwExtraInfo;
    }
    [StructLayout(LayoutKind.Explicit)]
    private struct INPUTUNION
    {
        [FieldOffset(0)] public KEYBDINPUT ki;
        [FieldOffset(0)] public MOUSEINPUT mi;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT { public uint type; public INPUTUNION data; }
    [StructLayout(LayoutKind.Sequential)]
    private struct RECT { public int left, top, right, bottom; }
    [StructLayout(LayoutKind.Sequential)]
    private struct GUITHREADINFO
    {
        public uint cbSize, flags;
        public IntPtr active, focus, capture, menuOwner, moveSize, caret;
        public RECT caretRect;
    }
    public sealed class Target
    {
        public long Window, Focus;
        public uint ThreadId;
        public string Layout;
        public string Method = "windows-user32-sendinput-keyboard-v1";
    }
    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool GetGUIThreadInfo(uint thread, ref GUITHREADINFO info);
    [DllImport("user32.dll")] private static extern IntPtr GetKeyboardLayout(uint thread);
    [DllImport("user32.dll")] private static extern IntPtr LoadKeyboardLayout(string id, uint flags);
    [DllImport("user32.dll")] private static extern bool PostMessage(IntPtr window, uint message, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll")] private static extern short GetKeyState(int key);
    [DllImport("user32.dll", SetLastError = true)] private static extern uint SendInput(uint count, INPUT[] inputs, int size);

    private static Target Inspect()
    {
        IntPtr window = GetForegroundWindow();
        uint processId;
        uint thread = GetWindowThreadProcessId(window, out processId);
        if (window == IntPtr.Zero || thread == 0)
            throw new InvalidOperationException("No foreground browser window.");
        string name = Process.GetProcessById((int)processId).ProcessName.ToLowerInvariant();
        if (name != "chrome" && name != "msedge" && name != "brave")
            throw new InvalidOperationException("Keyboard target is not a supported browser.");
        GUITHREADINFO info = new GUITHREADINFO();
        info.cbSize = (uint)Marshal.SizeOf(typeof(GUITHREADINFO));
        if (!GetGUIThreadInfo(thread, ref info) || info.focus == IntPtr.Zero || (info.flags & 0x1e) != 0)
            throw new InvalidOperationException("Browser keyboard focus is unavailable or a menu is open.");
        uint focusProcessId;
        uint focusThread = GetWindowThreadProcessId(info.focus, out focusProcessId);
        if (focusThread == 0 || focusProcessId != processId)
            throw new InvalidOperationException("Keyboard focus does not belong to the browser.");
        return new Target { Window = window.ToInt64(), Focus = info.focus.ToInt64(), ThreadId = focusThread,
            Layout = GetKeyboardLayout(focusThread).ToInt64().ToString("X") };
    }

    private static Target Verify(long window, long focus)
    {
        if (window == 0 || focus == 0) throw new InvalidOperationException("Missing verified keyboard target.");
        Target current = Inspect();
        if (current.Window != window || current.Focus != focus)
            throw new InvalidOperationException("Browser window or keyboard focus changed; keyboard input cancelled.");
        return current;
    }

    private static void VerifyModifiers()
    {
        foreach (int key in new int[] { 0x10, 0x11, 0x12, 0x5b, 0x5c })
            if ((GetAsyncKeyState(key) & 0x8000) != 0)
                throw new InvalidOperationException("Release Shift, Ctrl, Alt and Windows keys before automatic input.");
    }

    private static Target EnsureEnglish(long window, long focus)
    {
        Target current = Verify(window, focus);
        IntPtr layout = LoadKeyboardLayout("00000409", 0);
        if (layout == IntPtr.Zero) throw new InvalidOperationException("Cannot load the US English keyboard layout.");
        if (GetKeyboardLayout(current.ThreadId) != layout &&
            !PostMessage(new IntPtr(focus), 0x0050, IntPtr.Zero, layout))
            throw new InvalidOperationException("Cannot request US English keyboard layout.");
        for (int i = 0; i < 40; i++)
        {
            current = Verify(window, focus);
            if (GetKeyboardLayout(current.ThreadId) == layout) return current;
            Thread.Sleep(25);
        }
        throw new InvalidOperationException("Browser did not switch to US English; no keys were sent.");
    }

    private static INPUT Key(ushort key, bool up)
    {
        INPUT input = new INPUT();
        input.type = 1;
        input.data.ki.wVk = key;
        input.data.ki.dwFlags = up ? 2u : 0u;
        return input;
    }

    private static INPUT[] LetterEvents(char letter, bool capsLock)
    {
        if (letter < 'A' || letter > 'Z') throw new ArgumentException("Only uppercase ASCII letters are supported.");
        ushort key = (ushort)letter;
        // Caps Lock already produces uppercase. Never toggle the user's lock state.
        return capsLock ? new INPUT[] { Key(key, false), Key(key, true) } :
            new INPUT[] { Key(0x10, false), Key(key, false), Key(key, true), Key(0x10, true) };
    }

    private static void Send(INPUT[] events)
    {
        uint sent = SendInput((uint)events.Length, events, Marshal.SizeOf(typeof(INPUT)));
        if (sent == events.Length) return;
        int error = Marshal.GetLastWin32Error();
        // Release only keys whose down event was accepted in this batch. Do not
        // fall back to SendKeys, paste, Unicode packets, Enter or another submit.
        for (int i = 0; i < sent; i++)
        {
            if ((events[i].data.ki.dwFlags & 2) == 0)
            {
                INPUT[] release = new INPUT[] { Key(events[i].data.ki.wVk, true) };
                SendInput(1, release, Marshal.SizeOf(typeof(INPUT)));
            }
        }
        throw new Win32Exception(error, "SendInput keyboard failed (" + sent + "/" + events.Length + ").");
    }

    public static Target Execute(string action, string text, long window, long focus, int delayMs, int jitterMs)
    {
        if (action == "inspect") return Inspect();
        if (action != "clear" && action != "type") throw new ArgumentException("Unknown keyboard action.");
        if (action == "type" && (text == null || text.Length != 5)) throw new ArgumentException("Expected exactly five ASCII letters.");
        if (action == "type") foreach (char letter in text)
            if (letter < 'A' || letter > 'Z') throw new ArgumentException("Expected uppercase ASCII letters.");
        VerifyModifiers();
        Target target = EnsureEnglish(window, focus);
        IntPtr englishLayout = GetKeyboardLayout(target.ThreadId);
        if (action == "clear")
        {
            Send(new INPUT[] { Key(0x11, false), Key(0x41, false), Key(0x41, true), Key(0x11, true) });
            Thread.Sleep(100);
            Verify(window, focus);
            VerifyModifiers();
            Send(new INPUT[] { Key(0x08, false), Key(0x08, true) });
        }
        else
        {
            Random random = new Random();
            foreach (char letter in text)
            {
                target = Verify(window, focus);
                VerifyModifiers();
                // Verify the US layout again for each letter, including user changes mid-input.
                if (GetKeyboardLayout(target.ThreadId) != englishLayout)
                    throw new InvalidOperationException("Keyboard layout changed during input.");
                Send(LetterEvents(letter, (GetKeyState(0x14) & 1) != 0));
                Thread.Sleep(Math.Min(500, Math.Max(0, delayMs)) + random.Next(Math.Min(500, Math.Max(0, jitterMs)) + 1));
            }
        }
        return Verify(window, focus);
    }
}

public static class TicketlinkNativeClick
{
    [StructLayout(LayoutKind.Sequential)]
    private struct RECT
    {
        public int Left, Top, Right, Bottom;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT
    {
        public int X, Y;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool GetPhysicalCursorPos(out POINT point);

    private static bool physicalCoordinatesEnabled = false;

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool GetWindowRect(IntPtr window, out RECT rect);

    [DllImport("dwmapi.dll")]
    private static extern int DwmGetWindowAttribute(IntPtr window, int attribute, out RECT rect, int size);

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);

    [DllImport("user32.dll")]
    private static extern uint GetDpiForWindow(IntPtr window);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);

    public sealed class BrowserGeometry
    {
        public int WindowLeft, WindowTop, WindowRight, WindowBottom;
        public double BrowserScreenX, BrowserScreenY, DisplayScale;
        public uint Dpi;
        public string BoundsSource;

        public int ToPhysicalX(double value)
        {
            return (int)Math.Round(WindowLeft + (value - BrowserScreenX) * DisplayScale);
        }

        public int ToPhysicalY(double value)
        {
            return (int)Math.Round(WindowTop + (value - BrowserScreenY) * DisplayScale);
        }

        public void VerifyTarget(int x, int y)
        {
            if (x < WindowLeft || x >= WindowRight || y < WindowTop || y >= WindowBottom)
                throw new InvalidOperationException("Resolved target is outside the browser window. Refresh page coordinates.");
        }
    }

    // Use a physical window origin, not a globally scaled desktop origin:
    // adjacent displays can have different DPI values and negative positions.
    public static BrowserGeometry ConfigureBrowserGeometry(
        double browserScreenX, double browserScreenY,
        double browserWidth, double browserHeight, double expectedDisplayScale)
    {
        IntPtr previous = SetThreadDpiAwarenessContext(new IntPtr(-4));
        if (previous == IntPtr.Zero)
            previous = SetThreadDpiAwarenessContext(new IntPtr(-3));
        if (previous == IntPtr.Zero)
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Cannot enable physical DPI coordinates.");
        physicalCoordinatesEnabled = true;

        IntPtr window = GetForegroundWindow();
        uint processId;
        GetWindowThreadProcessId(window, out processId);
        string processName = Process.GetProcessById((int)processId).ProcessName.ToLowerInvariant();
        if (processName != "chrome" && processName != "msedge" && processName != "brave" && processName != "chromium")
            throw new InvalidOperationException("Foreground window is not a supported browser. Focus the target browser.");

        RECT rect;
        if (!GetWindowRect(window, out rect))
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Cannot read browser window bounds.");
        uint dpi = GetDpiForWindow(window);
        double scale = dpi / 96.0;
        if (dpi == 0 || Double.IsNaN(expectedDisplayScale) || Double.IsInfinity(expectedDisplayScale) ||
            expectedDisplayScale <= 0 || Math.Abs(scale - expectedDisplayScale) > 0.03)
            throw new InvalidOperationException("Browser and Windows DPI disagree. Keep the browser on one display and refresh coordinates.");

        // GetWindowRect can include invisible resize borders. Chrome's outer
        // dimensions vary with window style: choose the native bounds that
        // best match the browser snapshot, rather than adding those borders.
        string boundsSource = "GetWindowRect";
        RECT visibleRect;
        if (DwmGetWindowAttribute(window, 9, out visibleRect, Marshal.SizeOf(typeof(RECT))) == 0)
        {
            double rectError = Math.Abs((rect.Right - rect.Left) - browserWidth * scale) +
                Math.Abs((rect.Bottom - rect.Top) - browserHeight * scale);
            double visibleError = Math.Abs((visibleRect.Right - visibleRect.Left) - browserWidth * scale) +
                Math.Abs((visibleRect.Bottom - visibleRect.Top) - browserHeight * scale);
            if (visibleError + 2 < rectError)
            {
                rect = visibleRect;
                boundsSource = "DwmExtendedFrameBounds";
            }
        }
        double borderTolerance = Math.Max(24, 24 * scale);
        if (browserWidth <= 0 || browserHeight <= 0 ||
            Math.Abs((rect.Right - rect.Left) - browserWidth * scale) > borderTolerance ||
            Math.Abs((rect.Bottom - rect.Top) - browserHeight * scale) > borderTolerance)
            throw new InvalidOperationException("Browser window size changed or the wrong window is focused. Refresh coordinates.");

        return new BrowserGeometry {
            WindowLeft = rect.Left, WindowTop = rect.Top,
            WindowRight = rect.Right, WindowBottom = rect.Bottom,
            BrowserScreenX = browserScreenX, BrowserScreenY = browserScreenY,
            DisplayScale = scale, Dpi = dpi, BoundsSource = boundsSource
        };
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public UInt32 type;
        public MOUSEINPUT mi;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MOUSEINPUT
    {
        public Int32 dx;
        public Int32 dy;
        public UInt32 mouseData;
        public UInt32 dwFlags;
        public UInt32 time;
        public IntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool SetCursorPos(int X, int Y);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern UInt32 SendInput(UInt32 nInputs, INPUT[] pInputs, Int32 cbSize);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern void mouse_event(UInt32 dwFlags, UInt32 dx, UInt32 dy, UInt32 dwData, UIntPtr dwExtraInfo);

    [DllImport("user32.dll")]
    private static extern Int32 GetSystemMetrics(Int32 nIndex);

    private static Boolean usedMouseEventFallback = false;
    private static String fallbackReason = "";

    private const UInt32 INPUT_MOUSE = 0;
    private const UInt32 MOUSEEVENTF_MOVE = 0x0001;
    private const UInt32 MOUSEEVENTF_LEFTDOWN = 0x0002;
    private const UInt32 MOUSEEVENTF_LEFTUP = 0x0004;
    private const UInt32 MOUSEEVENTF_VIRTUALDESK = 0x4000;
    private const UInt32 MOUSEEVENTF_ABSOLUTE = 0x8000;

    private const Int32 SM_XVIRTUALSCREEN = 76;
    private const Int32 SM_YVIRTUALSCREEN = 77;
    private const Int32 SM_CXVIRTUALSCREEN = 78;
    private const Int32 SM_CYVIRTUALSCREEN = 79;

    private static Int32 NormalizeAbsoluteCoordinate(Int32 value, Int32 origin, Int32 size)
    {
        Int32 safeSize = Math.Max(1, size - 1);
        Double normalized = ((Double)(value - origin) * 65535.0) / safeSize;
        if (normalized < 0.0)
        {
            return 0;
        }
        if (normalized > 65535.0)
        {
            return 65535;
        }
        return (Int32)Math.Round(normalized);
    }

    private static void RememberFallback(String reason)
    {
        usedMouseEventFallback = true;
        if (String.IsNullOrEmpty(fallbackReason))
        {
            fallbackReason = reason;
        }
    }

    private static String ErrorText(String action, Int32 error)
    {
        return action + " failed (GetLastError=" + error + ")";
    }

    private static void SendAbsoluteMoveWithMouseEvent(int x, int y, String reason)
    {
        RememberFallback(reason);
        UInt32 normalizedX = (UInt32)NormalizeAbsoluteCoordinate(x, GetSystemMetrics(SM_XVIRTUALSCREEN), GetSystemMetrics(SM_CXVIRTUALSCREEN));
        UInt32 normalizedY = (UInt32)NormalizeAbsoluteCoordinate(y, GetSystemMetrics(SM_YVIRTUALSCREEN), GetSystemMetrics(SM_CYVIRTUALSCREEN));
        mouse_event(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK, normalizedX, normalizedY, 0, UIntPtr.Zero);
    }

    private static void SendAbsoluteMove(int x, int y)
    {
        INPUT[] inputs = new INPUT[1];
        inputs[0].type = INPUT_MOUSE;
        inputs[0].mi.dx = NormalizeAbsoluteCoordinate(x, GetSystemMetrics(SM_XVIRTUALSCREEN), GetSystemMetrics(SM_CXVIRTUALSCREEN));
        inputs[0].mi.dy = NormalizeAbsoluteCoordinate(y, GetSystemMetrics(SM_YVIRTUALSCREEN), GetSystemMetrics(SM_CYVIRTUALSCREEN));
        inputs[0].mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK;
        UInt32 sent = SendInput((UInt32)inputs.Length, inputs, Marshal.SizeOf(typeof(INPUT)));
        if (sent != inputs.Length)
        {
            Int32 error = Marshal.GetLastWin32Error();
            SendAbsoluteMoveWithMouseEvent(x, y, ErrorText("SendInput mouse move", error));
        }
    }

    private static void MoveCursor(int x, int y)
    {
        if (!SetCursorPos(x, y))
        {
            Int32 error = Marshal.GetLastWin32Error();
            SendAbsoluteMoveWithMouseEvent(x, y, ErrorText("SetCursorPos", error));
            return;
        }
        SendAbsoluteMove(x, y);
        if (physicalCoordinatesEnabled)
        {
            POINT actual;
            if (!GetPhysicalCursorPos(out actual) || Math.Abs(actual.X - x) > 2 || Math.Abs(actual.Y - y) > 2)
                throw new InvalidOperationException("Physical cursor did not reach the requested target. Click cancelled.");
        }
    }

    private static void SendMouseButton(UInt32 flag)
    {
        INPUT[] inputs = new INPUT[1];
        inputs[0].type = INPUT_MOUSE;
        inputs[0].mi.dwFlags = flag;
        UInt32 sent = SendInput((UInt32)inputs.Length, inputs, Marshal.SizeOf(typeof(INPUT)));
        if (sent != inputs.Length)
        {
            Int32 error = Marshal.GetLastWin32Error();
            RememberFallback(ErrorText("SendInput mouse button", error));
            mouse_event(flag, 0, 0, 0, UIntPtr.Zero);
        }
    }

    public static String Click(
        int x,
        int y,
        int? providedStartX,
        int? providedStartY,
        int hoverSettleMs,
        int clickHoldMs,
        int preDownSettleMs,
        int afterUpSettleMs,
        int trajectoryDurationMs
    )
    {
        usedMouseEventFallback = false;
        fallbackReason = "";

        Random random = new Random();
        int fallbackDistanceX = random.Next(60, 87);
        int fallbackDistanceY = random.Next(38, 59);
        int startX = providedStartX.HasValue
            ? providedStartX.Value
            : x + (x >= fallbackDistanceX + 4 ? -fallbackDistanceX : fallbackDistanceX);
        int startY = providedStartY.HasValue
            ? providedStartY.Value
            : y + (y >= fallbackDistanceY + 4 ? -fallbackDistanceY : fallbackDistanceY);
        int trajectoryMs = Math.Max(120, Math.Min(3000, trajectoryDurationMs));
        int steps = Math.Max(14, Math.Min(120, (int)Math.Ceiling(trajectoryMs / 18.0)));
        int stepDelayMs = Math.Max(1, (int)Math.Round((double)trajectoryMs / steps));
        int settleMs = Math.Max(0, Math.Min(900, hoverSettleMs));
        int holdMs = Math.Max(20, Math.Min(600, clickHoldMs));
        int preDownMs = Math.Max(0, Math.Min(300, preDownSettleMs));
        int afterUpMs = Math.Max(5, Math.Min(300, afterUpSettleMs));

        MoveCursor(startX, startY);
        Thread.Sleep(18);

        for (int step = 1; step <= steps; step++)
        {
            double progress = (double)step / steps;
            double jitter = step == steps ? 0 : random.NextDouble() * 2.0 - 1.0;
            int currentX = (int)Math.Round(startX + (x - startX) * progress + jitter);
            int currentY = (int)Math.Round(startY + (y - startY) * progress - jitter * 0.6);
            MoveCursor(currentX, currentY);
            Thread.Sleep(stepDelayMs);
        }

        MoveCursor(x >= 4 ? x - 2 : x + 2, y);
        Thread.Sleep(18);
        MoveCursor(x, y >= 4 ? y - 2 : y + 2);
        Thread.Sleep(18);
        MoveCursor(x >= 4 ? x - 1 : x + 1, y >= 4 ? y - 1 : y + 1);
        Thread.Sleep(18);
        MoveCursor(x, y);
        Thread.Sleep(settleMs);
        MoveCursor(x, y);
        Thread.Sleep(preDownMs);
        SendAbsoluteMove(x, y);
        Thread.Sleep(24);

        SendMouseButton(MOUSEEVENTF_LEFTDOWN);
        try
        {
            Thread.Sleep(holdMs);
            MoveCursor(x, y);
            Thread.Sleep(12);
        }
        finally
        {
            SendMouseButton(MOUSEEVENTF_LEFTUP);
        }
        Thread.Sleep(afterUpMs);

        if (usedMouseEventFallback)
        {
            return "windows-user32-sendinput-absolute+mouse_event_fallback:" + fallbackReason;
        }
        return "windows-user32-sendinput-absolute";
    }

    public static String Move(int x, int y)
    {
        usedMouseEventFallback = false;
        fallbackReason = "";
        MoveCursor(x, y);
        if (usedMouseEventFallback)
        {
            return "windows-user32-sendinput-absolute-move+mouse_event_fallback:" + fallbackReason;
        }
        return "windows-user32-sendinput-absolute-move";
    }

    public static String ClickInstant(int x, int y, int clickHoldMs, int afterUpSettleMs)
    {
        usedMouseEventFallback = false;
        fallbackReason = "";
        int holdMs = Math.Max(20, Math.Min(120, clickHoldMs));
        int afterUpMs = Math.Max(5, Math.Min(100, afterUpSettleMs));
        MoveCursor(x, y);
        SendAbsoluteMove(x, y);
        Thread.Sleep(8);
        SendMouseButton(MOUSEEVENTF_LEFTDOWN);
        Thread.Sleep(holdMs);
        SendMouseButton(MOUSEEVENTF_LEFTUP);
        Thread.Sleep(afterUpMs);
        if (usedMouseEventFallback)
        {
            return "windows-user32-sendinput-absolute-instant+mouse_event_fallback:" + fallbackReason;
        }
        return "windows-user32-sendinput-absolute-instant";
    }
}
