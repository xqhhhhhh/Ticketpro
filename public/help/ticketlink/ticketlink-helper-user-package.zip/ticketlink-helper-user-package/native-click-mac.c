#include <ApplicationServices/ApplicationServices.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static void fail(const char *message) {
  fprintf(stderr, "%s\n", message);
  exit(1);
}

static double parse_double_arg(const char *value, const char *label) {
  char *end = NULL;
  const double parsed = strtod(value, &end);
  if (value == NULL || end == value || *end != '\0' || !isfinite(parsed)) {
    fprintf(stderr, "invalid %s\n", label);
    exit(1);
  }
  return parsed;
}

static unsigned int clamp_uint_arg(const char *value, unsigned int fallback, unsigned int min_value, unsigned int max_value) {
  char *end = NULL;
  unsigned long parsed = strtoul(value, &end, 10);
  if (value == NULL || end == value || *end != '\0') {
    parsed = fallback;
  }
  if (parsed < min_value) {
    return min_value;
  }
  if (parsed > max_value) {
    return max_value;
  }
  return (unsigned int)parsed;
}

static double random_between(double min_value, double max_value) {
  const double ratio = (double)rand() / (double)RAND_MAX;
  return min_value + (max_value - min_value) * ratio;
}

static void sleep_ms(unsigned int milliseconds) {
  usleep((useconds_t)milliseconds * 1000);
}

static void post_move(CGEventSourceRef source, CGPoint previous, CGPoint destination) {
  CGWarpMouseCursorPosition(destination);
  CGEventRef move = CGEventCreateMouseEvent(source, kCGEventMouseMoved, destination, kCGMouseButtonLeft);
  if (move == NULL) {
    fail("failed to create mouse move event");
  }
  CGEventSetIntegerValueField(move, kCGMouseEventDeltaX, (int64_t)llround(destination.x - previous.x));
  CGEventSetIntegerValueField(move, kCGMouseEventDeltaY, (int64_t)llround(destination.y - previous.y));
  CGEventPost(kCGHIDEventTap, move);
  CFRelease(move);
}

static CGEventRef make_button_event(CGEventSourceRef source, CGEventType type, CGPoint point, double pressure) {
  CGEventRef event = CGEventCreateMouseEvent(source, type, point, kCGMouseButtonLeft);
  if (event == NULL) {
    fail("failed to create mouse button event");
  }
  CGEventSetIntegerValueField(event, kCGMouseEventButtonNumber, 0);
  CGEventSetIntegerValueField(event, kCGMouseEventClickState, 1);
  CGEventSetDoubleValueField(event, kCGMouseEventPressure, pressure);
  return event;
}

int main(int argc, char **argv) {
  if (argc >= 2 && (strcmp(argv[1], "--version") == 0 || strcmp(argv[1], "--self-test") == 0)) {
    puts("native-click-mac-cgevent-hid 1.3");
    return 0;
  }

  const bool move_only = argc >= 2 && strcmp(argv[1], "--move") == 0;
  const bool instant_click = argc >= 2 && strcmp(argv[1], "--instant") == 0;
  if ((!move_only && !instant_click && argc < 3) || ((move_only || instant_click) && argc < 4)) {
    fail("missing coordinates");
  }

  srand((unsigned int)(time(NULL) ^ getpid()));

  const int coordinate_offset = move_only || instant_click ? 1 : 0;
  const double x = parse_double_arg(argv[1 + coordinate_offset], "x");
  const double y = parse_double_arg(argv[2 + coordinate_offset], "y");
  const CGPoint point = CGPointMake(x, y);

  CGEventSourceRef source = CGEventSourceCreate(kCGEventSourceStateHIDSystemState);
  if (source == NULL) {
    fail("failed to create HID event source");
  }
  CGEventSourceSetLocalEventsSuppressionInterval(source, 0);
  CGAssociateMouseAndMouseCursorPosition(true);

  if (move_only) {
    post_move(source, point, point);
    CFRelease(source);
    puts("native-click-mac-cgevent-hid-move");
    return 0;
  }

  if (instant_click) {
    const unsigned int click_hold_ms = argc >= 5 ? clamp_uint_arg(argv[4], 35, 20, 120) : 35;
    const unsigned int after_up_settle_ms = argc >= 6 ? clamp_uint_arg(argv[5], 10, 5, 100) : 10;
    post_move(source, point, point);
    sleep_ms(8);
    CGEventRef down = make_button_event(source, kCGEventLeftMouseDown, point, 1.0);
    CGEventRef up = make_button_event(source, kCGEventLeftMouseUp, point, 0.0);
    CGEventPost(kCGHIDEventTap, down);
    sleep_ms(click_hold_ms);
    CGEventPost(kCGHIDEventTap, up);
    sleep_ms(after_up_settle_ms);
    CFRelease(down);
    CFRelease(up);
    CFRelease(source);
    puts("native-click-mac-cgevent-hid-instant");
    return 0;
  }

  const double default_hover_distance_x = random_between(60.0, 86.0);
  const double default_hover_distance_y = random_between(38.0, 58.0);
  CGPoint hover_start_point = CGPointMake(
    x + (x >= default_hover_distance_x + 4.0 ? -default_hover_distance_x : default_hover_distance_x),
    y + (y >= default_hover_distance_y + 4.0 ? -default_hover_distance_y : default_hover_distance_y)
  );

  if (argc >= 5) {
    hover_start_point = CGPointMake(
      parse_double_arg(argv[3], "hoverStartX"),
      parse_double_arg(argv[4], "hoverStartY")
    );
  }

  const unsigned int hover_settle_ms = argc >= 6 ? clamp_uint_arg(argv[5], 260, 0, 900) : 260;
  const unsigned int click_hold_ms = argc >= 7 ? clamp_uint_arg(argv[6], 220, 20, 600) : 220;
  const unsigned int pre_down_settle_ms = argc >= 8 ? clamp_uint_arg(argv[7], 100, 0, 300) : 100;
  const unsigned int after_up_settle_ms = argc >= 9 ? clamp_uint_arg(argv[8], 120, 5, 300) : 120;
  const unsigned int trajectory_duration_ms = argc >= 10 ? clamp_uint_arg(argv[9], 252, 120, 3000) : 252;

  int hover_move_steps = (int)ceil((double)trajectory_duration_ms / 18.0);
  if (hover_move_steps < 14) hover_move_steps = 14;
  if (hover_move_steps > 120) hover_move_steps = 120;
  const unsigned int hover_step_ms = (unsigned int)fmax(1.0, round((double)trajectory_duration_ms / (double)hover_move_steps));
  CGPoint current_point = hover_start_point;
  post_move(source, hover_start_point, hover_start_point);
  sleep_ms(hover_step_ms);

  for (int step = 1; step <= hover_move_steps; step += 1) {
    const double progress = (double)step / (double)hover_move_steps;
    const double jitter = step == hover_move_steps ? 0.0 : random_between(-1.0, 1.0);
    const CGPoint current = CGPointMake(
      hover_start_point.x + (point.x - hover_start_point.x) * progress + jitter,
      hover_start_point.y + (point.y - hover_start_point.y) * progress - jitter * 0.6
    );
    post_move(source, current_point, current);
    current_point = current;
    sleep_ms(hover_step_ms);
  }

  const CGPoint wiggle_points[] = {
    CGPointMake(x + (x >= 4.0 ? -2.0 : 2.0), y),
    CGPointMake(x, y + (y >= 4.0 ? -2.0 : 2.0)),
    CGPointMake(x + (x >= 4.0 ? -1.0 : 1.0), y + (y >= 4.0 ? -1.0 : 1.0)),
    point
  };
  for (size_t index = 0; index < sizeof(wiggle_points) / sizeof(wiggle_points[0]); index += 1) {
    post_move(source, current_point, wiggle_points[index]);
    current_point = wiggle_points[index];
    sleep_ms(hover_step_ms);
  }

  sleep_ms(hover_settle_ms);
  post_move(source, point, point);
  sleep_ms(pre_down_settle_ms);

  CGEventRef down = make_button_event(source, kCGEventLeftMouseDown, point, 1.0);
  CGEventRef up = make_button_event(source, kCGEventLeftMouseUp, point, 0.0);

  CGEventPost(kCGHIDEventTap, down);
  sleep_ms(click_hold_ms);
  post_move(source, point, point);
  usleep(12000);
  CGEventPost(kCGHIDEventTap, up);
  sleep_ms(after_up_settle_ms);

  CFRelease(down);
  CFRelease(up);
  CFRelease(source);
  return 0;
}
