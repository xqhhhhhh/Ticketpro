#!/bin/sh
set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Installing Ticketlink Helper machine identity host..."
sh "$SCRIPT_DIR/support/install-macos.sh"
echo ""
echo "Installation complete. You can close this window."
echo "If Chrome or Edge is open, restart the browser before activating."
echo ""
echo "本机组件安装完成。按任意键退出安装程序属于正常操作。"
echo "退出后，请继续查看安装教程，完成浏览器内的操作。"
/bin/bash -c 'IFS= read -r -s -n 1 -p "按任意键结束安装程序..."'
printf '\n'
