@echo off
setlocal
set "HOST_DIR=%~dp0"
set "POWERSHELL_EXE="
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "POWERSHELL_EXE=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not defined POWERSHELL_EXE if exist "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" set "POWERSHELL_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not defined POWERSHELL_EXE if exist "%WINDIR%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe" set "POWERSHELL_EXE=%WINDIR%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
if not defined POWERSHELL_EXE for /f "delims=" %%P in ('where powershell.exe 2^>nul') do if not defined POWERSHELL_EXE set "POWERSHELL_EXE=%%P"
if not defined POWERSHELL_EXE for /f "delims=" %%P in ('where pwsh.exe 2^>nul') do if not defined POWERSHELL_EXE set "POWERSHELL_EXE=%%P"
if defined POWERSHELL_EXE (
  "%POWERSHELL_EXE%" -NoProfile -ExecutionPolicy Bypass -File "%HOST_DIR%ticketlink_machine_id_host.ps1" %*
  exit /b %ERRORLEVEL%
)
>&2 echo powershell_not_found
exit /b 1
