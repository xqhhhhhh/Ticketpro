$ErrorActionPreference = "Stop"

$HostName = "com.ticketlink.machine_id"
$ExtensionId = "kfekhdmooccibghkcadgpbademohjedb"
$InstallDir = Join-Path $env:LOCALAPPDATA "TicketlinkHelperMachineId"
$SourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$HostScript = Join-Path $InstallDir "ticketlink_machine_id_host.ps1"
$HostCmd = Join-Path $InstallDir "ticketlink_machine_id_host.cmd"
$ManifestPath = Join-Path $InstallDir "$HostName.json"

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item -Force (Join-Path $SourceDir "ticketlink_machine_id_host.ps1") $HostScript
Copy-Item -Force (Join-Path $SourceDir "ticketlink_machine_id_host.cmd") $HostCmd

$Manifest = @{
  name = $HostName
  description = "Ticketlink Helper machine identity host"
  path = $HostCmd
  type = "stdio"
  allowed_origins = @("chrome-extension://$ExtensionId/")
} | ConvertTo-Json -Depth 5

Set-Content -Path $ManifestPath -Value $Manifest -Encoding UTF8

$ChromeKey = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName"
$EdgeKey = "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$HostName"
New-Item -Force -Path $ChromeKey | Out-Null
New-Item -Force -Path $EdgeKey | Out-Null
Set-Item -Path $ChromeKey -Value $ManifestPath
Set-Item -Path $EdgeKey -Value $ManifestPath

$DeviceId = & $HostCmd --print-id
if ($LASTEXITCODE -ne 0 -or -not ($DeviceId -match '^devm_[a-f0-9]{64}$')) {
  throw "Machine identity host self-test failed. Please send a screenshot of this window to support."
}
Write-Host "Ticketlink Helper machine identity host installed."
