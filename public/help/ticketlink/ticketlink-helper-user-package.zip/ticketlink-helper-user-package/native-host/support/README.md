# Ticketlink Helper Machine Identity Host

Native Messaging host used by the extension to bind licenses to a real machine.

Host name: `com.ticketlink.machine_id`

Registered extension ID: `kfekhdmooccibghkcadgpbademohjedb`

No Python or third-party runtime is required. The installer uses built-in
system tools on macOS and Windows.

## macOS

For normal users, double-click:

```text
Install-TicketlinkHelper-mac.command
```

If macOS blocks it, right-click the file, choose Open, then confirm Open.

Technical command:

```sh
sh native-host/support/install-macos.sh
```

The installer registers the host for Chrome and Edge under the current user.

After installation, fully quit and reopen Chrome or Edge.

## Windows

For normal users, double-click:

```text
Install-TicketlinkHelper-windows.bat
```

Technical command:

```powershell
powershell -ExecutionPolicy Bypass -File native-host\support\install-windows.ps1
```

The installer registers the host for Chrome and Edge under the current user.
After installation, fully quit and reopen Chrome or Edge.

If the browser reports `error when communicating with the native messaging host`,
open PowerShell and run:

```powershell
& "$env:LOCALAPPDATA\TicketlinkHelperMachineId\ticketlink_machine_id_host.cmd" --print-id
```

The output must start with `devm_`. If it does not, rerun the installer and send
a screenshot of the installer window to support.

## Test

macOS:

```sh
~/Library/Application\ Support/TicketlinkHelperMachineId/ticketlink_machine_id_host_macos.sh --print-id
```

Windows PowerShell:

```powershell
& "$env:LOCALAPPDATA\TicketlinkHelperMachineId\ticketlink_machine_id_host.cmd" --print-id
```

Developer source test on macOS:

```sh
native-host/support/ticketlink_machine_id_host_macos.sh --print-id
```

The output must start with `devm_`.
