$ErrorActionPreference = "Stop"

$AppNamespace = "ticketlink-machine-id:v1"

function Get-MachineDeviceId {
  $machineGuid = ""
  $views = @(
    [Microsoft.Win32.RegistryView]::Registry64,
    [Microsoft.Win32.RegistryView]::Registry32
  )

  foreach ($view in $views) {
    try {
      $baseKey = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $view)
      $key = $baseKey.OpenSubKey("SOFTWARE\Microsoft\Cryptography")
      if ($null -ne $key) {
        $value = [string]$key.GetValue("MachineGuid", "")
        if (-not [string]::IsNullOrWhiteSpace($value)) {
          $machineGuid = $value.Trim()
          break
        }
      }
    } catch {
      # Try the next registry view.
    }
  }

  if ([string]::IsNullOrWhiteSpace($machineGuid)) {
    throw "MachineGuid not found"
  }

  $raw = "${AppNamespace}:windows:${machineGuid}"
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($raw)
    $hash = $sha.ComputeHash($bytes)
    $hex = -join ($hash | ForEach-Object { $_.ToString("x2") })
    return "devm_$hex"
  } finally {
    $sha.Dispose()
  }
}

function Read-NativeMessage {
  $stdin = [Console]::OpenStandardInput()
  $lengthBytes = New-Object byte[] 4
  $read = $stdin.Read($lengthBytes, 0, 4)
  if ($read -ne 4) {
    return $null
  }
  $length = [BitConverter]::ToUInt32($lengthBytes, 0)
  if ($length -le 0 -or $length -gt 1048576) {
    throw "invalid native message length"
  }
  $buffer = New-Object byte[] $length
  $offset = 0
  while ($offset -lt $length) {
    $chunk = $stdin.Read($buffer, $offset, $length - $offset)
    if ($chunk -le 0) {
      throw "invalid native message body"
    }
    $offset += $chunk
  }
  return [System.Text.Encoding]::UTF8.GetString($buffer)
}

function Write-NativeMessage($Payload) {
  $json = $Payload | ConvertTo-Json -Compress -Depth 5
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
  $lengthBytes = [BitConverter]::GetBytes([UInt32]$bytes.Length)
  $stdout = [Console]::OpenStandardOutput()
  $stdout.Write($lengthBytes, 0, 4)
  $stdout.Write($bytes, 0, $bytes.Length)
  $stdout.Flush()
}

try {
  if ($args -contains "--print-id") {
    Write-Output (Get-MachineDeviceId)
    exit 0
  }

  [void](Read-NativeMessage)
  Write-NativeMessage @{
    ok = $true
    device_id = Get-MachineDeviceId
  }
  exit 0
} catch {
  if ($args -contains "--print-id") {
    Write-Error $_.Exception.Message
    exit 1
  }
  try {
    Write-NativeMessage @{
      ok = $false
      error = $_.Exception.Message
    }
  } catch {
    # Browser will surface a native host communication error.
  }
  exit 1
}
