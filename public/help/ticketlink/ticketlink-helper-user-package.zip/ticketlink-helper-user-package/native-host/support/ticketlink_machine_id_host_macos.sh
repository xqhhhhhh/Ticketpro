#!/bin/sh
set -eu

APP_NAMESPACE="ticketlink-machine-id:v1"

get_machine_uuid() {
  ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null \
    | awk -F= '/IOPlatformUUID/ { gsub(/[ "]/, "", $2); print $2; exit }'
}

get_machine_device_id() {
  raw_uuid="$(get_machine_uuid)"
  if [ -z "$raw_uuid" ]; then
    echo "IOPlatformUUID not found" >&2
    exit 1
  fi
  printf '%s' "$APP_NAMESPACE:darwin:$raw_uuid" \
    | shasum -a 256 \
    | awk '{ print "devm_" $1 }'
}

write_native_message() {
  payload="$1"
  /usr/bin/perl -e 'use strict; use warnings; binmode STDOUT; my $s = $ARGV[0]; print pack("L<", length($s)); print $s;' "$payload"
}

if [ "${1:-}" = "--print-id" ]; then
  get_machine_device_id
  exit 0
fi

device_id="$(get_machine_device_id)"
write_native_message "{\"ok\":true,\"device_id\":\"$device_id\"}"
