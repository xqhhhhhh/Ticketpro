#!/bin/sh
set -eu

HOST_NAME="com.ticketlink.machine_id"
EXTENSION_ID="kfekhdmooccibghkcadgpbademohjedb"
INSTALL_DIR="$HOME/Library/Application Support/TicketlinkHelperMachineId"
HOST_SCRIPT="$INSTALL_DIR/ticketlink_machine_id_host_macos.sh"

mkdir -p "$INSTALL_DIR"
cp "$(dirname "$0")/ticketlink_machine_id_host_macos.sh" "$HOST_SCRIPT"
chmod 755 "$HOST_SCRIPT"

write_manifest() {
  browser_dir="$1"
  manifest_dir="$HOME/Library/Application Support/$browser_dir/NativeMessagingHosts"
  manifest_path="$manifest_dir/$HOST_NAME.json"
  mkdir -p "$manifest_dir"
  cat > "$manifest_path" <<EOF
{
  "name": "$HOST_NAME",
  "description": "Ticketlink Helper machine identity host",
  "path": "$HOST_SCRIPT",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://$EXTENSION_ID/"
  ]
}
EOF
  echo "Registered $HOST_NAME for $browser_dir"
}

write_manifest "Google/Chrome"
write_manifest "Microsoft Edge"

"$HOST_SCRIPT" --print-id >/dev/null
echo "Ticketlink Helper machine identity host installed."
