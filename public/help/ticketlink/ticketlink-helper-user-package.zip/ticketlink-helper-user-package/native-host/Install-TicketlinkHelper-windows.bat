@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo Installing Ticketlink Helper machine identity host...
set "POWERSHELL_EXE="
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "POWERSHELL_EXE=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not defined POWERSHELL_EXE if exist "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" set "POWERSHELL_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not defined POWERSHELL_EXE if exist "%WINDIR%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe" set "POWERSHELL_EXE=%WINDIR%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
if not defined POWERSHELL_EXE for /f "delims=" %%P in ('where powershell.exe 2^>nul') do if not defined POWERSHELL_EXE set "POWERSHELL_EXE=%%P"
if not defined POWERSHELL_EXE for /f "delims=" %%P in ('where pwsh.exe 2^>nul') do if not defined POWERSHELL_EXE set "POWERSHELL_EXE=%%P"
if not defined POWERSHELL_EXE (
  echo.
  echo PowerShell was not found on this computer. Please install Windows PowerShell or PowerShell 7 and try again.
  pause
  exit /b 1
)
"%POWERSHELL_EXE%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0support\install-windows.ps1"
if errorlevel 1 (
  echo.
  echo Installation failed. Please send a screenshot of this window to support.
  pause
  exit /b 1
)
echo.
echo Installation complete. Restart Chrome or Edge before activating.
echo 本机组件安装完成。按任意键退出安装程序属于正常操作。
echo 退出后，请继续查看安装教程，完成浏览器内的操作。
echo.
pause
