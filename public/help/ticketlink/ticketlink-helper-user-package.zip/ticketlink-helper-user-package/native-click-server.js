const http = require("node:http");
const { execFile, execFileSync } = require("node:child_process");
const { createHash } = require("node:crypto");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

const PORT = Number(process.env.TICKETLINK_CLICK_PORT || 19776);
const HOST = "127.0.0.1";
const ROOT = __dirname;
const PLATFORM = os.platform();
const MAC_CLICK_SOURCE = path.join(ROOT, "native-click-mac.c");
const WINDOWS_CLICK_SCRIPT = path.join(ROOT, "native-click-windows.ps1");
const WINDOWS_CLICK_SOURCE = path.join(ROOT, "native-click-windows.cs");
const MAC_CLICK_BINARY_BY_ARCH = {
  arm64: path.join(ROOT, "native-click-mac-arm64"),
  x64: path.join(ROOT, "native-click-mac-x64")
};
const MAC_BROWSER_APPS = ["Google Chrome", "Chromium", "Microsoft Edge", "Brave Browser", "Arc"];
const WINDOWS_BROWSER_PROCESSES = ["chrome", "msedge", "brave", "chromium"];

const delayFromEnv = (name, fallback) => {
  const value = Number(process.env[name]);
  return Number.isFinite(value) && value >= 0 ? value : fallback;
};

const CAPTCHA_KEY_DELAY_MS = delayFromEnv("TICKETLINK_CAPTCHA_KEY_DELAY_MS", 240);
const CAPTCHA_KEY_DELAY_JITTER_MS = delayFromEnv("TICKETLINK_CAPTCHA_KEY_DELAY_JITTER_MS", 100);
const BROWSER_FOCUS_SETTLE_MS = delayFromEnv("TICKETLINK_BROWSER_FOCUS_SETTLE_MS", 300);
const CAPTCHA_INPUT_FOCUS_SETTLE_MS = delayFromEnv("TICKETLINK_CAPTCHA_INPUT_FOCUS_SETTLE_MS", 450);
const CLICK_HOVER_SETTLE_MS = delayFromEnv("TICKETLINK_CLICK_HOVER_SETTLE_MS", 260);
const CLICK_HOVER_RECT_MARGIN_PX = delayFromEnv("TICKETLINK_CLICK_HOVER_RECT_MARGIN_PX", 24);
const CLICK_HOVER_FALLBACK_DISTANCE_PX = delayFromEnv("TICKETLINK_CLICK_HOVER_FALLBACK_DISTANCE_PX", 72);
const CLICK_PRE_DOWN_SETTLE_MS = delayFromEnv("TICKETLINK_CLICK_PRE_DOWN_SETTLE_MS", 100);
const CLICK_HOLD_MS = delayFromEnv("TICKETLINK_CLICK_HOLD_MS", 220);
const CLICK_AFTER_UP_SETTLE_MS = delayFromEnv("TICKETLINK_CLICK_AFTER_UP_SETTLE_MS", 120);
const CLICK_TRAJECTORY_DURATION_MS = delayFromEnv("TICKETLINK_CLICK_TRAJECTORY_DURATION_MS", 252);
const CLICK_PREPARE_TTL_MS = delayFromEnv("TICKETLINK_CLICK_PREPARE_TTL_MS", 2500);
const CLICK_PREPARE_MATCH_TOLERANCE_PX = delayFromEnv("TICKETLINK_CLICK_PREPARE_MATCH_TOLERANCE_PX", 5);
const MAC_CLICK_COMPILE_TIMEOUT_MS = delayFromEnv(
  "TICKETLINK_MAC_CLICK_COMPILE_TIMEOUT_MS",
  delayFromEnv("TICKETLINK_SWIFT_CLICK_COMPILE_TIMEOUT_MS", 8000)
);
const WINDOWS_CLICK_PROCESS_TIMEOUT_MS = delayFromEnv("TICKETLINK_WINDOWS_CLICK_TIMEOUT_MS", 15000);
const WINDOWS_CLICK_WARMUP_TIMEOUT_MS = delayFromEnv("TICKETLINK_WINDOWS_CLICK_WARMUP_TIMEOUT_MS", 30000);
const WINDOWS_MOVE_PROCESS_TIMEOUT_MS = delayFromEnv("TICKETLINK_WINDOWS_MOVE_TIMEOUT_MS", 6000);

const MAC_INPUT_SOURCE_SWIFT_SOURCE = String.raw`
import Carbon
import Foundation

func stringProperty(_ source: TISInputSource, _ key: CFString) -> String {
    guard let pointer = TISGetInputSourceProperty(source, key) else { return "" }
    let value = Unmanaged<CFTypeRef>.fromOpaque(pointer).takeUnretainedValue()
    return value as? String ?? ""
}

let preferredIds = [
    "com.apple.keylayout.ABC",
    "com.apple.keylayout.US",
    "com.apple.keylayout.British",
    "com.apple.keylayout.Australian"
]
let preferredNames = ["ABC", "U.S.", "US", "English", "British", "Australian"]
let inputSources = TISCreateInputSourceList(nil, false).takeRetainedValue() as NSArray
var selected: TISInputSource?

for preferredId in preferredIds {
    for case let source as TISInputSource in inputSources {
        if stringProperty(source, kTISPropertyInputSourceID) == preferredId {
            selected = source
            break
        }
    }
    if selected != nil { break }
}

if selected == nil {
    for preferredName in preferredNames {
        for case let source as TISInputSource in inputSources {
            if stringProperty(source, kTISPropertyLocalizedName) == preferredName {
                selected = source
                break
            }
        }
        if selected != nil { break }
    }
}

guard let source = selected else {
    fputs("No ABC/US input source found\n", stderr)
    exit(2)
}

let status = TISSelectInputSource(source)
if status != noErr {
    fputs("TISSelectInputSource failed: \(status)\n", stderr)
    exit(3)
}

print(stringProperty(source, kTISPropertyInputSourceID))
`;

const MAC_KEYBOARD_SWIFT_SOURCE = String.raw`
import CoreGraphics
import Darwin
import Foundation

func fail(_ message: String) -> Never {
    FileHandle.standardError.write(Data((message + "\n").utf8))
    exit(1)
}

let keyMap: [Character: CGKeyCode] = [
    "A": 0, "B": 11, "C": 8, "D": 2, "E": 14, "F": 3, "G": 5, "H": 4,
    "I": 34, "J": 38, "K": 40, "L": 37, "M": 46, "N": 45, "O": 31, "P": 35,
    "Q": 12, "R": 15, "S": 1, "T": 17, "U": 32, "V": 9, "W": 13, "X": 7,
    "Y": 16, "Z": 6
]

guard CommandLine.arguments.count >= 3 else {
    fail("missing captcha text")
}

let text = CommandLine.arguments[1].uppercased()
let delayMs = max(0, UInt32(CommandLine.arguments[2]) ?? 120)
let jitterMs = CommandLine.arguments.count >= 4 ? max(0, UInt32(CommandLine.arguments[3]) ?? 0) : 0
let source = CGEventSource(stateID: .hidSystemState)
source?.localEventsSuppressionInterval = 0

func tapKey(_ keyCode: CGKeyCode, flags: CGEventFlags = []) {
    guard
        let down = CGEvent(keyboardEventSource: source, virtualKey: keyCode, keyDown: true),
        let up = CGEvent(keyboardEventSource: source, virtualKey: keyCode, keyDown: false)
    else {
        fail("failed to create keyboard events")
    }
    down.flags = flags
    up.flags = flags
    down.post(tap: .cghidEventTap)
    usleep(25_000)
    up.post(tap: .cghidEventTap)
}

tapKey(0, flags: .maskCommand)
usleep(70_000)
tapKey(51)
usleep(60_000)

for _ in 0..<5 {
    tapKey(51)
    usleep(30_000)
}

for char in text {
    guard let keyCode = keyMap[char] else {
        fail("unsupported captcha character: \(char)")
    }
    tapKey(keyCode, flags: .maskShift)
    let randomizedDelayMs = delayMs + (jitterMs > 0 ? UInt32.random(in: 0...jitterMs) : 0)
    if randomizedDelayMs > 0 {
        usleep(randomizedDelayMs * 1000)
    }
}

print("swift-cgevent-keyboard")
`;

const json = (res, status, body, origin = "") => {
  if (origin.startsWith("chrome-extension://")) {
    res.setHeader("Access-Control-Allow-Origin", origin);
  }
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Ticketlink-Seat-Helper");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Private-Network", "true");
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.writeHead(status);
  res.end(JSON.stringify(body));
};

const readBody = (req) => new Promise((resolve, reject) => {
  let data = "";
  req.setEncoding("utf8");
  req.on("data", (chunk) => {
    data += chunk;
    if (data.length > 32768) {
      reject(new Error("request body too large"));
      req.destroy();
    }
  });
  req.on("end", () => resolve(data));
  req.on("error", reject);
});

const run = (file, args, timeout = 2500) => new Promise((resolve, reject) => {
  execFile(file, args, { timeout }, (error, stdout, stderr) => {
    if (error) {
      const timeoutMessage = error.killed
        ? `command timed out after ${timeout} ms${error.signal ? ` (${error.signal})` : ""}`
        : "";
      const exitMessage = !error.killed && Number.isFinite(Number(error.code))
        ? `command exited with code ${error.code}`
        : "";
      const details = [stderr, stdout, timeoutMessage, exitMessage, error.message]
        .map((value) => String(value || "").trim())
        .filter((value, index, values) => value && values.indexOf(value) === index);
      reject(new Error(details.join("\n") || String(error)));
      return;
    }
    resolve((stdout || "").trim());
  });
});

const optionalFiniteNumber = (value) => {
  if (value === null || value === undefined || value === "") {
    return null;
  }
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : null;
};

const normalizeScreenRect = (value) => {
  if (!value || typeof value !== "object") {
    return null;
  }
  const left = optionalFiniteNumber(value.left);
  const top = optionalFiniteNumber(value.top);
  const width = optionalFiniteNumber(value.width);
  const height = optionalFiniteNumber(value.height);
  const right = optionalFiniteNumber(value.right);
  const bottom = optionalFiniteNumber(value.bottom);
  if (left === null || top === null) {
    return null;
  }

  const normalizedWidth = width !== null && width > 0 ? width : right !== null ? right - left : 0;
  const normalizedHeight = height !== null && height > 0 ? height : bottom !== null ? bottom - top : 0;
  if (normalizedWidth <= 0 || normalizedHeight <= 0) {
    return null;
  }

  return {
    left,
    top,
    right: right !== null ? right : left + normalizedWidth,
    bottom: bottom !== null ? bottom : top + normalizedHeight,
    width: normalizedWidth,
    height: normalizedHeight
  };
};

const normalizeScreenBounds = (value) => {
  if (!value || typeof value !== "object") {
    return null;
  }
  const left = optionalFiniteNumber(value.screenX);
  const top = optionalFiniteNumber(value.screenY);
  const width = optionalFiniteNumber(value.outerWidth);
  const height = optionalFiniteNumber(value.outerHeight);
  if (left === null || top === null || width === null || height === null || width <= 0 || height <= 0) {
    return null;
  }
  return {
    left,
    top,
    right: left + width,
    bottom: top + height
  };
};

const distanceSquared = (left, top, right, bottom) => {
  const dx = left - right;
  const dy = top - bottom;
  return dx * dx + dy * dy;
};

const isPointInBounds = (point, bounds) => !bounds || (
  point.x >= bounds.left + 1 &&
  point.y >= bounds.top + 1 &&
  point.x <= bounds.right - 1 &&
  point.y <= bounds.bottom - 1
);

const clampPointToBounds = (point, bounds) => {
  if (!bounds) {
    return point;
  }
  return {
    x: Math.min(Math.max(point.x, bounds.left + 1), bounds.right - 1),
    y: Math.min(Math.max(point.y, bounds.top + 1), bounds.bottom - 1)
  };
};

const normalizeClickStrategy = () => {
  return "swift_hid";
};

const computeHoverStartPoint = (x, y, elementScreenRect, windowMetrics = null) => {
  const margin = Math.max(8, CLICK_HOVER_RECT_MARGIN_PX);
  const rect = normalizeScreenRect(elementScreenRect);
  const bounds = normalizeScreenBounds(windowMetrics);
  if (rect) {
    const midX = rect.left + rect.width / 2;
    const midY = rect.top + rect.height / 2;
    const candidates = [
      { x: rect.left - margin, y: midY },
      { x: rect.right + margin, y: midY },
      { x: midX, y: rect.top - margin },
      { x: midX, y: rect.bottom + margin }
    ].filter((point) => point.x >= 1 && point.y >= 1 && isPointInBounds(point, bounds));

    if (candidates.length > 0) {
      candidates.sort((a, b) => distanceSquared(b.x, b.y, x, y) - distanceSquared(a.x, a.y, x, y));
      return {
        x: Math.round(candidates[0].x),
        y: Math.round(candidates[0].y),
        source: "element_rect"
      };
    }
  }

  const distance = Math.max(32, CLICK_HOVER_FALLBACK_DISTANCE_PX);
  const offsetX = x >= distance + 4 ? -distance : distance;
  const offsetY = y >= Math.round(distance * 0.7) + 4 ? -Math.round(distance * 0.7) : Math.round(distance * 0.7);
  const fallbackPoint = clampPointToBounds({
    x: x + offsetX,
    y: y + offsetY
  }, bounds);
  return {
    x: Math.round(fallbackPoint.x),
    y: Math.round(fallbackPoint.y),
    source: "fallback_offset"
  };
};

const ensureExecutableFile = (filePath) => {
  try {
    fs.accessSync(filePath, fs.constants.X_OK);
  } catch (_error) {
    fs.chmodSync(filePath, 0o755);
  }
  fs.accessSync(filePath, fs.constants.X_OK);
};

const getBundledMacClickBinary = () => {
  const bundledPath = MAC_CLICK_BINARY_BY_ARCH[os.arch()];
  if (!bundledPath || !fs.existsSync(bundledPath)) {
    return "";
  }
  try {
    ensureExecutableFile(bundledPath);
    return bundledPath;
  } catch (_error) {
    return "";
  }
};

const verifyMacClickBinary = async (binaryPath) => {
  ensureExecutableFile(binaryPath);
  const version = await run(binaryPath, ["--version"], 3000);
  if (!/^native-click-mac-cgevent-hid\b/.test(version)) {
    throw new Error(`macOS 点击程序自检返回异常：${version || "empty output"}`);
  }
  return version;
};

const supportsMacInstantClick = (version) => {
  const match = String(version || "").match(/\b(\d+)\.(\d+)\b/);
  if (!match) {
    return false;
  }
  const major = Number(match[1]);
  const minor = Number(match[2]);
  return major > 1 || (major === 1 && minor >= 2);
};

const supportsMacTrajectoryDuration = (version) => {
  const match = String(version || "").match(/\b(\d+)\.(\d+)\b/);
  if (!match) {
    return false;
  }
  const major = Number(match[1]);
  const minor = Number(match[2]);
  return major > 1 || (major === 1 && minor >= 3);
};

const getCompiledMacClickBinary = () => {
  if (!fs.existsSync(MAC_CLICK_SOURCE)) {
    throw new Error("缺少 macOS 点击文件 native-click-mac.c。");
  }
  const sourceHash = createHash("sha256").update(fs.readFileSync(MAC_CLICK_SOURCE)).digest("hex").slice(0, 16);
  return path.join(os.tmpdir(), `ticketlink-native-click-${os.arch()}-${sourceHash}`);
};

let clickBinaryCompilePromise = null;
let clickBinaryCompileError = "";

const compileClickBinary = async () => {
  if (clickBinaryCompileError) {
    throw new Error(clickBinaryCompileError);
  }
  const clickBinary = getCompiledMacClickBinary();
  if (fs.existsSync(clickBinary)) {
    return clickBinary;
  }
  if (!clickBinaryCompilePromise) {
    const minimumVersion = os.arch() === "x64" ? "10.15" : "11.0";
    clickBinaryCompilePromise = run(
      "clang",
      [
        MAC_CLICK_SOURCE,
        "-O2",
        `-mmacosx-version-min=${minimumVersion}`,
        "-framework",
        "ApplicationServices",
        "-o",
        clickBinary
      ],
      MAC_CLICK_COMPILE_TIMEOUT_MS
    )
      .then(() => clickBinary)
      .catch((error) => {
        clickBinaryCompileError = `macOS 点击程序编译失败或超时：${error.message}`;
        throw new Error(clickBinaryCompileError);
      });
  }
  return clickBinaryCompilePromise;
};

const getMacClickBinary = async (options = {}) => {
  if (options.requireMove === true) {
    const compiledPath = await compileClickBinary();
    const version = await verifyMacClickBinary(compiledPath);
    return {
      binaryPath: compiledPath,
      source: "compiled",
      version
    };
  }

  const bundledPath = getBundledMacClickBinary();
  let bundledError = "";
  if (bundledPath) {
    try {
      const version = await verifyMacClickBinary(bundledPath);
      if (options.requireInstant === true && !supportsMacInstantClick(version)) {
        throw new Error(`内置 macOS 点击程序版本过低，不支持瞬移点击：${version}`);
      }
      if (options.requireTrajectoryDuration === true && !supportsMacTrajectoryDuration(version)) {
        throw new Error(`内置 macOS 点击程序版本过低，不支持轨迹速度：${version}`);
      }
      return {
        binaryPath: bundledPath,
        source: "bundled",
        version
      };
    } catch (error) {
      bundledError = error?.message || String(error);
    }
  }
  try {
    const compiledPath = await compileClickBinary();
    const version = await verifyMacClickBinary(compiledPath);
    return {
      binaryPath: compiledPath,
      source: "compiled",
      version,
      bundledError
    };
  } catch (error) {
    if (bundledError) {
      throw new Error(`内置 macOS 点击程序不可用：${bundledError}；备用编译也失败：${error.message}`);
    }
    throw error;
  }
};

const getMacInputSourceBinary = () => {
  const swiftHash = createHash("sha256").update(MAC_INPUT_SOURCE_SWIFT_SOURCE).digest("hex").slice(0, 16);
  const sourcePath = path.join(os.tmpdir(), `ticketlink-input-source-${swiftHash}.swift`);
  const binaryPath = path.join(os.tmpdir(), `ticketlink-input-source-${swiftHash}`);
  if (!fs.existsSync(sourcePath) || fs.readFileSync(sourcePath, "utf8") !== MAC_INPUT_SOURCE_SWIFT_SOURCE) {
    fs.writeFileSync(sourcePath, MAC_INPUT_SOURCE_SWIFT_SOURCE);
  }
  return { sourcePath, binaryPath };
};

const compileMacInputSourceBinary = () => {
  const { sourcePath, binaryPath } = getMacInputSourceBinary();
  if (fs.existsSync(binaryPath)) {
    return binaryPath;
  }
  execFileSync("swiftc", [sourcePath, "-O", "-o", binaryPath], { stdio: "pipe" });
  return binaryPath;
};

const getMacKeyboardBinary = () => {
  const swiftHash = createHash("sha256").update(MAC_KEYBOARD_SWIFT_SOURCE).digest("hex").slice(0, 16);
  const sourcePath = path.join(os.tmpdir(), `ticketlink-keyboard-${swiftHash}.swift`);
  const binaryPath = path.join(os.tmpdir(), `ticketlink-keyboard-${swiftHash}`);
  if (!fs.existsSync(sourcePath) || fs.readFileSync(sourcePath, "utf8") !== MAC_KEYBOARD_SWIFT_SOURCE) {
    fs.writeFileSync(sourcePath, MAC_KEYBOARD_SWIFT_SOURCE);
  }
  return { sourcePath, binaryPath };
};

const compileMacKeyboardBinary = () => {
  const { sourcePath, binaryPath } = getMacKeyboardBinary();
  if (fs.existsSync(binaryPath)) {
    return binaryPath;
  }
  execFileSync("swiftc", [sourcePath, "-O", "-o", binaryPath], { stdio: "pipe" });
  return binaryPath;
};

const getPowerShellExecutable = () => {
  if (process.env.SystemRoot) {
    return path.join(process.env.SystemRoot, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
  }
  return "powershell.exe";
};

const ensureWindowsClickFiles = () => {
  const missing = [];
  if (!fs.existsSync(WINDOWS_CLICK_SCRIPT)) {
    missing.push("native-click-windows.ps1");
  }
  if (!fs.existsSync(WINDOWS_CLICK_SOURCE)) {
    missing.push("native-click-windows.cs");
  }
  if (missing.length) {
    throw new Error(`缺少 Windows 点击文件：${missing.join("、")}。请完整解压同一个后端压缩包，不要只替换单个文件。`);
  }
};

let windowsClickWarmupPromise = null;

const ensureWindowsClickHelperReady = () => {
  ensureWindowsClickFiles();
  if (!windowsClickWarmupPromise) {
    windowsClickWarmupPromise = run(
      getPowerShellExecutable(),
      ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", WINDOWS_CLICK_SCRIPT, "-Warmup"],
      WINDOWS_CLICK_WARMUP_TIMEOUT_MS
    ).catch((error) => {
      windowsClickWarmupPromise = null;
      throw error;
    });
  }
  return windowsClickWarmupPromise;
};

const POWERSHELL_UTF8_PREAMBLE = [
  "$utf8NoBom = New-Object System.Text.UTF8Encoding($false)",
  "[Console]::OutputEncoding = $utf8NoBom",
  "$OutputEncoding = $utf8NoBom"
].join("; ");

const runPowerShellCommand = (command, timeout = 2500) => run(
  getPowerShellExecutable(),
  ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", `${POWERSHELL_UTF8_PREAMBLE};\n${command}`],
  timeout
);

const activateBrowserMac = async () => {
  for (const appName of MAC_BROWSER_APPS) {
    try {
      const escapedAppName = appName.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
      const output = await run("osascript", [
        "-e", "set browserPid to 0",
        "-e", `tell application "${escapedAppName}" to activate`,
        "-e", "delay 0.05",
        "-e", "try",
        "-e", "tell application \"System Events\"",
        "-e", `if exists process "${escapedAppName}" then`,
        "-e", `tell process "${escapedAppName}"`,
        "-e", "set frontmost to true",
        "-e", "set browserPid to unix id",
        "-e", "end tell",
        "-e", "end if",
        "-e", "end tell",
        "-e", "end try",
        "-e", "return browserPid"
      ], 2500);
      return {
        appName,
        pid: Math.max(0, Math.floor(Number(output) || 0))
      };
    } catch (_error) {}
  }
  return { appName: "", pid: 0 };
};

const activateBrowserWindows = async () => {
  const quotedProcesses = WINDOWS_BROWSER_PROCESSES.map((name) => `"${name}"`).join(",");
  const command = `
$shell = New-Object -ComObject WScript.Shell;
$names = @(${quotedProcesses});
foreach ($name in $names) {
  $windowProcs = @(Get-Process -Name $name -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Sort-Object Id -Descending);
  foreach ($proc in $windowProcs) {
    if ($proc -and $shell.AppActivate($proc.Id)) {
      Start-Sleep -Milliseconds 120;
      Write-Output "$($proc.ProcessName):$($proc.Id)";
      exit 0;
    }
  }
}
foreach ($name in $names) {
  $allProcs = @(Get-Process -Name $name -ErrorAction SilentlyContinue | Sort-Object Id -Descending);
  foreach ($proc in $allProcs) {
    if ($proc -and $shell.AppActivate($proc.Id)) {
      Start-Sleep -Milliseconds 120;
      Write-Output "$($proc.ProcessName):$($proc.Id)";
      exit 0;
    }
  }
}
exit 1;
`;
  try {
    const output = await runPowerShellCommand(command, 2500);
    const [appName, pidText] = String(output || "").split(":");
    return {
      appName: appName || "",
      pid: Math.max(0, Math.floor(Number(pidText) || 0))
    };
  } catch (_error) {
    return { appName: "", pid: 0 };
  }
};

const activateBrowser = async () => {
  if (PLATFORM === "darwin") {
    return activateBrowserMac();
  }
  if (PLATFORM === "win32") {
    return activateBrowserWindows();
  }
  return { appName: "", pid: 0 };
};

const clickWithMacHelper = async (x, y, options = {}) => {
  const instant = options.instant === true;
  const clickHelper = await getMacClickBinary({
    requireInstant: instant,
    requireTrajectoryDuration: !instant
  });
  const clickBinary = clickHelper.binaryPath;
  if (instant) {
    const output = await run(clickBinary, [
      "--instant",
      String(x),
      String(y),
      String(Math.round(options.clickHoldMs || 35)),
      String(Math.round(options.afterUpSettleMs || 10))
    ], 3000);
    return output || "native-click-mac-cgevent-hid-instant";
  }
  const args = [String(x), String(y)];
  if (Number.isFinite(options.hoverStartX) && Number.isFinite(options.hoverStartY)) {
    args.push(String(Math.round(options.hoverStartX)), String(Math.round(options.hoverStartY)));
    args.push(String(Math.round(optionalFiniteNumber(options.hoverSettleMs) ?? CLICK_HOVER_SETTLE_MS)));
    args.push(String(Math.round(optionalFiniteNumber(options.clickHoldMs) ?? CLICK_HOLD_MS)));
    args.push(String(Math.round(optionalFiniteNumber(options.preDownSettleMs) ?? CLICK_PRE_DOWN_SETTLE_MS)));
    args.push(String(Math.round(optionalFiniteNumber(options.afterUpSettleMs) ?? CLICK_AFTER_UP_SETTLE_MS)));
    args.push(String(Math.round(optionalFiniteNumber(options.trajectoryDurationMs) ?? CLICK_TRAJECTORY_DURATION_MS)));
  }
  const trajectoryDurationMs = Math.max(0, optionalFiniteNumber(options.trajectoryDurationMs) ?? CLICK_TRAJECTORY_DURATION_MS);
  await run(clickBinary, args, Math.max(5000, trajectoryDurationMs + 4000));
  return "coregraphics-cgevent-hover-hid";
};

const clickWithWindowsPowerShell = async (x, y, options = {}) => {
  await ensureWindowsClickHelperReady();
  const args = ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", WINDOWS_CLICK_SCRIPT];
  if (options.instant === true) {
    args.push(
      "-X", String(x),
      "-Y", String(y),
      "-Instant",
      "-ClickHoldMs", String(Math.round(options.clickHoldMs || 35)),
      "-AfterUpSettleMs", String(Math.round(options.afterUpSettleMs || 10))
    );
  } else {
    args.push(String(x), String(y));
  }
  if (options.instant !== true && Number.isFinite(options.hoverStartX) && Number.isFinite(options.hoverStartY)) {
    args.push(String(Math.round(options.hoverStartX)), String(Math.round(options.hoverStartY)));
    args.push(String(Math.round(optionalFiniteNumber(options.hoverSettleMs) ?? CLICK_HOVER_SETTLE_MS)));
    args.push(String(Math.round(optionalFiniteNumber(options.clickHoldMs) ?? CLICK_HOLD_MS)));
    args.push(String(Math.round(optionalFiniteNumber(options.preDownSettleMs) ?? CLICK_PRE_DOWN_SETTLE_MS)));
    args.push(String(Math.round(optionalFiniteNumber(options.afterUpSettleMs) ?? CLICK_AFTER_UP_SETTLE_MS)));
    args.push(String(Math.round(optionalFiniteNumber(options.trajectoryDurationMs) ?? CLICK_TRAJECTORY_DURATION_MS)));
  }
  appendWindowsGeometryArgs(args, options);
  const trajectoryDurationMs = Math.max(0, optionalFiniteNumber(options.trajectoryDurationMs) ?? CLICK_TRAJECTORY_DURATION_MS);
  const output = await run(
    getPowerShellExecutable(),
    args,
    Math.max(WINDOWS_CLICK_PROCESS_TIMEOUT_MS, trajectoryDurationMs + 12000)
  );
  return readWindowsNativeResult(output, options, "windows-user32-sendinput");
};

const appendWindowsGeometryArgs = (args, options) => {
  if (options.coordinateTransform && options.coordinateTransform.coordinateSpace === "browser-dip-v1") {
    args.push("-GeometryJson", JSON.stringify({
      windowMetrics: options.windowMetrics,
      expectedDisplayScale: options.coordinateTransform.expectedDisplayScale
    }));
  }
};

const readWindowsNativeResult = (output, options, fallback) => {
  if (String(output || "").trim().startsWith("{")) {
    const result = JSON.parse(output);
    if (!result || !result.method || !Number.isFinite(result.x) || !Number.isFinite(result.y)) {
      throw new Error("Windows 点击程序返回的坐标信息无效。");
    }
    if (options.nativeResult) Object.assign(options.nativeResult, result);
    return result.method;
  }
  if (options.coordinateTransform && options.coordinateTransform.coordinateSpace === "browser-dip-v1") {
    throw new Error("Windows 点击后端版本过旧，请更新完整 package 并重启后端。");
  }
  return output || fallback;
};

const moveWithMacHelper = async (x, y) => {
  const clickHelper = await getMacClickBinary();
  const output = await run(clickHelper.binaryPath, ["--move", String(x), String(y)], 3000);
  return output || "native-click-mac-cgevent-hid-move";
};

const moveWithWindowsPowerShell = async (x, y, options = {}) => {
  await ensureWindowsClickHelperReady();
  const args = ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", WINDOWS_CLICK_SCRIPT, "-X", String(x), "-Y", String(y), "-MoveOnly"];
  appendWindowsGeometryArgs(args, options);
  const output = await run(
    getPowerShellExecutable(),
    args,
    WINDOWS_MOVE_PROCESS_TIMEOUT_MS
  );
  return readWindowsNativeResult(output, options, "windows-user32-sendinput-absolute-move");
};

const nativeClickMac = async (x, y, options = {}) => {
  return clickWithMacHelper(x, y, options);
};

const nativeClick = async (x, y, options = {}) => {
  if (PLATFORM === "darwin") {
    return nativeClickMac(x, y, options);
  }
  if (PLATFORM === "win32") {
    return clickWithWindowsPowerShell(x, y, options);
  }
  throw new Error(`当前系统暂不支持真实鼠标点击：${PLATFORM}`);
};

const nativeMove = async (x, y, options = {}) => {
  if (PLATFORM === "darwin") {
    return moveWithMacHelper(x, y);
  }
  if (PLATFORM === "win32") {
    return moveWithWindowsPowerShell(x, y, options);
  }
  throw new Error(`当前系统暂不支持真实鼠标移动：${PLATFORM}`);
};

const normalizeCaptchaCode = (value) =>
  String(value || "").trim().toUpperCase().replace(/[^A-Z]/g, "").slice(0, 5);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const runAppleScriptLines = async (lines, timeout = 3500) => {
  const args = [];
  lines.forEach((line) => {
    args.push("-e", line);
  });
  return run("osascript", args, timeout);
};

const ensureEnglishInputSourceMac = async () => {
  try {
    const output = await run(compileMacInputSourceBinary(), [], 3500);
    return `swift-tis-english:${output || "ABC"}`;
  } catch (error) {
    return `swift-tis-english-unavailable:${error.message}`;
  }
};

const escapeAppleScriptString = (value) =>
  String(value || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"');

const randomCaptchaKeyDelayMs = () => {
  if (CAPTCHA_KEY_DELAY_JITTER_MS <= 0) {
    return CAPTCHA_KEY_DELAY_MS;
  }
  return CAPTCHA_KEY_DELAY_MS + Math.floor(Math.random() * (CAPTCHA_KEY_DELAY_JITTER_MS + 1));
};

const nativeTypeTextMacSwift = async (text) => {
  const output = await run(
    compileMacKeyboardBinary(),
    [text, String(CAPTCHA_KEY_DELAY_MS), String(CAPTCHA_KEY_DELAY_JITTER_MS)],
    6000
  );
  return output || "swift-cgevent-keyboard";
};

const nativeTypeTextMacAppleScript = async (text) => {
  const lines = [
    'tell application "System Events"',
    'delay 0.080',
    'keystroke "a" using command down',
    'delay 0.060',
    'key code 51',
    'delay 0.060'
  ];
  for (let index = 0; index < 5; index += 1) {
    lines.push('key code 51');
    lines.push('delay 0.030');
  }
  for (const char of text) {
    if (!/^[A-Z]$/.test(char)) {
      throw new Error(`不支持的验证码字符：${char}`);
    }
    lines.push(`keystroke "${escapeAppleScriptString(char)}"`);
    const delayMs = randomCaptchaKeyDelayMs();
    if (delayMs > 0) {
      const delaySeconds = (delayMs / 1000).toFixed(3);
      lines.push(`delay ${delaySeconds}`);
    }
  }
  lines.push("end tell");
  await runAppleScriptLines(lines);
  return "osascript-system-events-text-keystroke";
};

const nativeTypeTextMac = async (text) => {
  const inputSourceMethod = await ensureEnglishInputSourceMac();
  try {
    const method = await nativeTypeTextMacSwift(text);
    return `${inputSourceMethod}+${method}`;
  } catch (swiftError) {
    try {
      const method = await nativeTypeTextMacAppleScript(text);
      return `${inputSourceMethod}+${method}`;
    } catch (appleScriptError) {
      throw new Error(`Swift 键盘输入失败：${swiftError.message}；AppleScript 键盘输入失败：${appleScriptError.message}`);
    }
  }
};

// Keyboard actions use the same cached C# helper as native mouse input.
const runWindowsKeyboardAction = async (action, text = "", target = {}) => {
  await ensureWindowsClickHelperReady();
  const args = [
    "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", WINDOWS_CLICK_SCRIPT,
    "-KeyboardAction", action,
    "-ExpectedWindow", String(target.Window || 0), "-ExpectedFocus", String(target.Focus || 0),
    "-KeyDelayMs", String(CAPTCHA_KEY_DELAY_MS), "-KeyJitterMs", String(CAPTCHA_KEY_DELAY_JITTER_MS)
  ];
  if (action === "type") args.push("-Text", text);
  const output = await run(getPowerShellExecutable(), args, 10000);
  let result;
  try { result = JSON.parse(output.trim()); } catch (_) {
    throw new Error("Windows 键盘后端返回无效结果，请更新完整用户包并重启本地后端。");
  }
  if (!result.Window || !result.Focus || result.Method !== "windows-user32-sendinput-keyboard-v1") {
    throw new Error("Windows 键盘后端版本过旧，请更新完整用户包并重启本地后端。");
  }
  return result;
};

const nativeTypeTextWindows = async (text) => {
  // Retain the old combined protocol for older extension tabs. New tabs use
  // focus/clear/write and skip clear entirely when the input is already empty.
  const target = await runWindowsKeyboardAction("inspect");
  await runWindowsKeyboardAction("clear", "", target);
  const result = await runWindowsKeyboardAction("type", text, target);
  return result.Method;
};

const nativeTypeText = async (text) => {
  const normalized = normalizeCaptchaCode(text);
  if (!/^[A-Z]{5}$/.test(normalized)) {
    throw new Error("验证码必须是 5 位大写英文字母。");
  }
  if (PLATFORM === "darwin") {
    return nativeTypeTextMac(normalized);
  }
  if (PLATFORM === "win32") {
    return nativeTypeTextWindows(normalized);
  }
  throw new Error(`当前系统暂不支持真实键盘输入：${PLATFORM}`);
};

let lastPreparedNextClick = null;

const isPreparedNextClick = (x, y) => {
  if (!lastPreparedNextClick) {
    return false;
  }
  if (Date.now() - lastPreparedNextClick.preparedAt > CLICK_PREPARE_TTL_MS) {
    return false;
  }
  return (
    Math.abs(Number(lastPreparedNextClick.x) - x) <= CLICK_PREPARE_MATCH_TOLERANCE_PX &&
    Math.abs(Number(lastPreparedNextClick.y) - y) <= CLICK_PREPARE_MATCH_TOLERANCE_PX
  );
};

const handlePrepareNext = async (req, res, origin) => {
  if (req.headers["x-ticketlink-seat-helper"] !== "1") {
    json(res, 403, { ok: false, message: "缺少插件请求标记。" }, origin);
    return;
  }

  const raw = await readBody(req);
  const body = raw ? JSON.parse(raw) : {};
  const focusOnly = body.focusOnly === true;
  const browserFocused = body.browserFocused === true;
  if (focusOnly) {
    const browserTarget = browserFocused
      ? { appName: "", pid: 0 }
      : await activateBrowser();
    if (!browserFocused) {
      await sleep(BROWSER_FOCUS_SETTLE_MS);
    }

    let method = "";
    if (PLATFORM === "darwin") {
      const helper = await getMacClickBinary({ requireInstant: true });
      method = `mac-helper-warm:${helper.source}:${helper.version}`;
    } else if (PLATFORM === "win32") {
      ensureWindowsClickFiles();
      method = "windows-powershell-script-ready";
    } else {
      throw new Error(`当前系统暂不支持真实鼠标点击：${PLATFORM}`);
    }

    json(res, 200, {
      ok: true,
      prepared: false,
      warmed: true,
      focusOnly: true,
      browserFocused,
      method,
      appName: browserTarget.appName || "",
      browserPid: browserTarget.pid || 0,
      focusSettleMs: browserFocused ? 0 : BROWSER_FOCUS_SETTLE_MS,
      message: "已提前完成下一步真实点击链路预热，鼠标位置未改变。"
    }, origin);
    return;
  }

  const x = Number(body.screenX);
  const y = Number(body.screenY);

  if (!Number.isFinite(x) || !Number.isFinite(y)) {
    json(res, 400, { ok: false, message: "请求里没有有效屏幕坐标。" }, origin);
    return;
  }

  const roundedX = Math.round(x);
  const roundedY = Math.round(y);
  const browserTarget = browserFocused
    ? { appName: "", pid: 0 }
    : await activateBrowser();
  if (!browserFocused) {
    await sleep(BROWSER_FOCUS_SETTLE_MS);
  }
  const nativeResult = {};
  const method = await nativeMove(roundedX, roundedY, {
    windowMetrics: body.windowMetrics,
    coordinateTransform: body.coordinateTransform,
    nativeResult
  });
  lastPreparedNextClick = {
    x: roundedX,
    y: roundedY,
    preparedAt: Date.now(),
    method,
    appName: browserTarget.appName || "",
    browserPid: browserTarget.pid || 0
  };

  json(res, 200, {
    ok: true,
    prepared: true,
    x: nativeResult.x ?? roundedX,
    y: nativeResult.y ?? roundedY,
    logicalPoint: { x: roundedX, y: roundedY },
    coordinateDiagnostics: nativeResult.coordinateDiagnostics || null,
    method,
    appName: browserTarget.appName || "",
    browserPid: browserTarget.pid || 0,
    browserFocused,
    focusSettleMs: browserFocused ? 0 : BROWSER_FOCUS_SETTLE_MS,
    prepareTtlMs: CLICK_PREPARE_TTL_MS,
    message: `已提前聚焦浏览器并将鼠标移动到下一步按钮 (${nativeResult.x ?? roundedX}, ${nativeResult.y ?? roundedY})。`
  }, origin);
};

const handleClickNext = async (req, res, origin) => {
  if (req.headers["x-ticketlink-seat-helper"] !== "1") {
    json(res, 403, { ok: false, message: "缺少插件请求标记。" }, origin);
    return;
  }

  const raw = await readBody(req);
  const body = raw ? JSON.parse(raw) : {};
  const x = Number(body.screenX);
  const y = Number(body.screenY);

  if (!Number.isFinite(x) || !Number.isFinite(y)) {
    json(res, 400, { ok: false, message: "请求里没有有效屏幕坐标。" }, origin);
    return;
  }

  const roundedX = Math.round(x);
  const roundedY = Math.round(y);
  // 旧页面脚本没有传 instant 时保持快速模式；只有插件明确传 false
  // 才恢复带鼠标轨迹和悬停等待的旧版兼容点击路径。
  const forceHoverApproach = body.forceHoverApproach === true;
  const instant = !forceHoverApproach && body.instant !== false;
  const browserFocused = body.browserFocused === true;
  const prepared = !forceHoverApproach && (
    body.prepared === true || isPreparedNextClick(roundedX, roundedY)
  );
  const requestedHoverStartX = optionalFiniteNumber(body.hoverStartX);
  const requestedHoverStartY = optionalFiniteNumber(body.hoverStartY);
  const hoverStart = prepared && requestedHoverStartX !== null && requestedHoverStartY !== null
    ? { x: Math.round(requestedHoverStartX), y: Math.round(requestedHoverStartY), source: "prepared_center" }
    : computeHoverStartPoint(roundedX, roundedY, body.elementScreenRect, body.windowMetrics);
  const requestedHoverSettleMs = optionalFiniteNumber(body.hoverSettleMs);
  const requestedClickHoldMs = optionalFiniteNumber(body.clickHoldMs);
  const requestedPreDownSettleMs = optionalFiniteNumber(body.preDownSettleMs);
  const requestedAfterUpSettleMs = optionalFiniteNumber(body.afterUpSettleMs);
  const requestedTrajectoryDurationMs = optionalFiniteNumber(body.trajectoryDurationMs);
  const hoverSettleMs = instant ? 0 : Math.round(requestedHoverSettleMs ?? (prepared ? 80 : CLICK_HOVER_SETTLE_MS));
  const clickHoldMs = instant ? 35 : Math.round(requestedClickHoldMs ?? (prepared ? 80 : CLICK_HOLD_MS));
  const preDownSettleMs = instant ? 0 : Math.round(requestedPreDownSettleMs ?? (prepared ? 20 : CLICK_PRE_DOWN_SETTLE_MS));
  const afterUpSettleMs = instant ? 10 : Math.round(requestedAfterUpSettleMs ?? (prepared ? 30 : CLICK_AFTER_UP_SETTLE_MS));
  const trajectoryDurationMs = instant ? 0 : Math.round(requestedTrajectoryDurationMs ?? CLICK_TRAJECTORY_DURATION_MS);
  const clickStrategy = normalizeClickStrategy(body.clickStrategy);
  const browserTarget = prepared && lastPreparedNextClick
    ? {
      appName: lastPreparedNextClick.appName || "",
      pid: lastPreparedNextClick.browserPid || 0
    }
    : browserFocused
      ? { appName: "", pid: 0 }
      : await activateBrowser();
  if (!prepared && !browserFocused) {
    await sleep(BROWSER_FOCUS_SETTLE_MS);
  }
  let hoverLeaveMethod = "";
  if (forceHoverApproach && PLATFORM === "darwin") {
    hoverLeaveMethod = await nativeMove(hoverStart.x, hoverStart.y);
    await sleep(40);
  } else if (forceHoverApproach && PLATFORM === "win32") {
    // Windows 的完整慢速点击脚本本身会先定位到 hoverStart，再逐步进入目标。
    // 合并为一次 PowerShell 调用，避免旧环境在单独的 -MoveOnly 预移动阶段失败。
    hoverLeaveMethod = "windows-integrated-hover-trajectory";
  }
  const nativeResult = {};
  const method = await nativeClick(roundedX, roundedY, {
    windowMetrics: body.windowMetrics,
    coordinateTransform: body.coordinateTransform,
    nativeResult,
    hoverStartX: hoverStart.x,
    hoverStartY: hoverStart.y,
    hoverSettleMs,
    clickHoldMs,
    preDownSettleMs,
    afterUpSettleMs,
    trajectoryDurationMs,
    clickStrategy,
    instant
  });

  json(res, 200, {
    ok: true,
    x: nativeResult.x ?? roundedX,
    y: nativeResult.y ?? roundedY,
    logicalPoint: { x: roundedX, y: roundedY },
    coordinateDiagnostics: nativeResult.coordinateDiagnostics || null,
    coordinateTransform: body.coordinateTransform || null,
    method,
    appName: browserTarget.appName || "",
    browserPid: browserTarget.pid || 0,
    prepared,
    instant,
    forceHoverApproach,
    browserFocused,
    focusSettleMs: prepared || browserFocused ? 0 : BROWSER_FOCUS_SETTLE_MS,
    hoverStart: nativeResult.hoverStart || hoverStart,
    logicalHoverStart: hoverStart,
    hoverLeaveMethod,
    hoverSettleMs,
    preDownSettleMs,
    clickHoldMs,
    afterUpSettleMs,
    trajectoryDurationMs,
    clickStrategy,
    message: forceHoverApproach
      ? `已先将鼠标移到按钮外侧，再移动进入屏幕坐标 (${nativeResult.x ?? roundedX}, ${nativeResult.y ?? roundedY}) 完成点击。`
      : `已通过后端真实鼠标在屏幕坐标 (${nativeResult.x ?? roundedX}, ${nativeResult.y ?? roundedY}) 点击下一步。`
  }, origin);
};

const handleCaptchaType = async (req, res, origin) => {
  if (req.headers["x-ticketlink-seat-helper"] !== "1") {
    json(res, 403, { ok: false, message: "缺少插件请求标记。" }, origin);
    return;
  }

  const raw = await readBody(req);
  const body = raw ? JSON.parse(raw) : {};
  const action = String(body.action || "all").trim().toLowerCase();
  const code = normalizeCaptchaCode(body.code);
  const inputX = Number(body.inputScreenX);
  const inputY = Number(body.inputScreenY);
  const submitX = Number(body.submitScreenX);
  const submitY = Number(body.submitScreenY);
  const refreshX = Number(body.refreshScreenX);
  const refreshY = Number(body.refreshScreenY);

  if (!["all", "type", "submit", "refresh", "focus", "clear", "write"].includes(action)) {
    json(res, 400, { ok: false, message: "验证码后端动作无效。" }, origin);
    return;
  }

  if ((action === "all" || action === "type" || action === "write") && !/^[A-Z]{5}$/.test(code)) {
    json(res, 400, { ok: false, message: "请求里没有有效的 5 位验证码。" }, origin);
    return;
  }

  if ((action === "all" || action === "type" || action === "focus") && (!Number.isFinite(inputX) || !Number.isFinite(inputY))) {
    json(res, 400, { ok: false, message: "请求里没有验证码输入框屏幕坐标。" }, origin);
    return;
  }

  if ((action === "all" || action === "submit") && (!Number.isFinite(submitX) || !Number.isFinite(submitY))) {
    json(res, 400, { ok: false, message: "请求里没有验证码下一步按钮屏幕坐标。" }, origin);
    return;
  }
  if (action === "refresh" && (!Number.isFinite(refreshX) || !Number.isFinite(refreshY))) {
    json(res, 400, { ok: false, message: "请求里没有验证码刷新按钮屏幕坐标。" }, origin);
    return;
  }

  const roundedInputX = Number.isFinite(inputX) ? Math.round(inputX) : null;
  const roundedInputY = Number.isFinite(inputY) ? Math.round(inputY) : null;
  const roundedSubmitX = Number.isFinite(submitX) ? Math.round(submitX) : null;
  const roundedSubmitY = Number.isFinite(submitY) ? Math.round(submitY) : null;
  const roundedRefreshX = Number.isFinite(refreshX) ? Math.round(refreshX) : null;
  const roundedRefreshY = Number.isFinite(refreshY) ? Math.round(refreshY) : null;
  const keyboardOnly = action === "clear" || action === "write";
  if ((keyboardOnly || action === "focus") && PLATFORM !== "win32") {
    throw new Error("分步键盘输入仅用于 Windows 后端。");
  }
  // Do not steal focus back during a keyboard phase. A user/tab/dialog change
  // must fail the native target check instead of typing into a new target.
  const browserTarget = keyboardOnly ? {} : await activateBrowser();
  if (!keyboardOnly) await sleep(BROWSER_FOCUS_SETTLE_MS);

  let inputClickMethod = "";
  let typeMethod = "";
  let submitMethod = "";
  let refreshMethod = "";
  let keyboardTarget = null;
  const inputNativeResult = {};
  const submitNativeResult = {};
  const refreshNativeResult = {};

  if (action === "all" || action === "type" || action === "focus") {
    const hoverStart = computeHoverStartPoint(roundedInputX, roundedInputY, body.inputElementScreenRect, body.windowMetrics);
    inputClickMethod = await nativeClick(roundedInputX, roundedInputY, {
      windowMetrics: body.windowMetrics,
      coordinateTransform: body.coordinateTransform,
      nativeResult: inputNativeResult,
      hoverStartX: hoverStart.x,
      hoverStartY: hoverStart.y,
      hoverSettleMs: CLICK_HOVER_SETTLE_MS,
      clickHoldMs: CLICK_HOLD_MS,
      preDownSettleMs: CLICK_PRE_DOWN_SETTLE_MS,
      afterUpSettleMs: CLICK_AFTER_UP_SETTLE_MS
    });
    await sleep(CAPTCHA_INPUT_FOCUS_SETTLE_MS);
    if (action === "focus") {
      keyboardTarget = await runWindowsKeyboardAction("inspect");
    } else {
      typeMethod = await nativeTypeText(code);
      await sleep(180);
    }
  }

  if (keyboardOnly) {
    keyboardTarget = await runWindowsKeyboardAction(action === "write" ? "type" : "clear", action === "write" ? code : "", body.keyboardTarget || {});
    typeMethod = keyboardTarget.Method;
    await sleep(180);
  }

  if (action === "all" || action === "submit") {
    const hoverStart = computeHoverStartPoint(roundedSubmitX, roundedSubmitY, body.submitElementScreenRect, body.windowMetrics);
    submitMethod = await nativeClick(roundedSubmitX, roundedSubmitY, {
      windowMetrics: body.windowMetrics,
      coordinateTransform: body.coordinateTransform,
      nativeResult: submitNativeResult,
      hoverStartX: hoverStart.x,
      hoverStartY: hoverStart.y,
      hoverSettleMs: CLICK_HOVER_SETTLE_MS,
      clickHoldMs: CLICK_HOLD_MS,
      preDownSettleMs: CLICK_PRE_DOWN_SETTLE_MS,
      afterUpSettleMs: CLICK_AFTER_UP_SETTLE_MS
    });
  }

  if (action === "refresh") {
    const hoverStart = computeHoverStartPoint(roundedRefreshX, roundedRefreshY, body.refreshElementScreenRect, body.windowMetrics);
    refreshMethod = await nativeClick(roundedRefreshX, roundedRefreshY, {
      windowMetrics: body.windowMetrics,
      coordinateTransform: body.coordinateTransform,
      nativeResult: refreshNativeResult,
      hoverStartX: hoverStart.x,
      hoverStartY: hoverStart.y,
      hoverSettleMs: CLICK_HOVER_SETTLE_MS,
      clickHoldMs: CLICK_HOLD_MS,
      preDownSettleMs: CLICK_PRE_DOWN_SETTLE_MS,
      afterUpSettleMs: CLICK_AFTER_UP_SETTLE_MS
    });
    await sleep(250);
  }

  json(res, 200, {
    ok: true,
    action,
    code,
    appName: browserTarget.appName || "",
    browserPid: browserTarget.pid || 0,
    inputX: inputNativeResult.x ?? roundedInputX,
    inputY: inputNativeResult.y ?? roundedInputY,
    submitX: submitNativeResult.x ?? roundedSubmitX,
    submitY: submitNativeResult.y ?? roundedSubmitY,
    refreshX: refreshNativeResult.x ?? roundedRefreshX,
    refreshY: refreshNativeResult.y ?? roundedRefreshY,
    coordinateDiagnostics: {
      input: inputNativeResult.coordinateDiagnostics || null,
      submit: submitNativeResult.coordinateDiagnostics || null,
      refresh: refreshNativeResult.coordinateDiagnostics || null
    },
    inputClickMethod,
    typeMethod,
    keyboardTarget,
    captchaInputProtocol: PLATFORM === "win32" ? "phased-keyboard-v1" : "legacy",
    submitMethod,
    refreshMethod,
    focusSettleMs: BROWSER_FOCUS_SETTLE_MS,
    inputFocusSettleMs: CAPTCHA_INPUT_FOCUS_SETTLE_MS,
    keyDelayMs: CAPTCHA_KEY_DELAY_MS,
    keyDelayJitterMs: CAPTCHA_KEY_DELAY_JITTER_MS,
    submitted: action === "all" || action === "submit",
    refreshed: action === "refresh",
    method: `native_backend:${[inputClickMethod, typeMethod, submitMethod, refreshMethod].filter(Boolean).join("+")}`,
    message: {
      refresh: "已通过后端真实点击刷新验证码。",
      focus: "已点击验证码输入框并读取 Windows 键盘焦点。",
      clear: "已通过 Windows 原生按键清空验证码。",
      write: "已通过 Windows 原生按键输入验证码，等待页面核对。",
      type: "已通过后端键盘输入验证码，尚未提交。",
      submit: "已通过后端真实点击提交验证码。",
      all: "已通过后端真实点击输入框、键盘输入验证码并提交。"
    }[action]
  }, origin);
};

const buildHealthPayload = async () => {
  const supported = PLATFORM === "darwin" || PLATFORM === "win32";
  const payload = {
    ok: supported,
    port: PORT,
    platform: PLATFORM,
    supported,
    coordinateProtocol: PLATFORM === "win32" ? "browser-dip-v1" : "native-screen",
    captchaInputProtocol: PLATFORM === "win32" ? "phased-keyboard-v1" : "legacy"
  };

  if (PLATFORM === "darwin") {
    try {
      const helper = await getMacClickBinary();
      return {
        status: 200,
        body: {
          ...payload,
          ok: true,
          clickHelper: {
            ok: true,
            source: helper.source,
            name: path.basename(helper.binaryPath),
            version: helper.version,
            bundledError: helper.bundledError || ""
          }
        }
      };
    } catch (error) {
      return {
        status: 503,
        body: {
          ...payload,
          ok: false,
          clickHelper: {
            ok: false,
            message: error?.message || String(error)
          },
          message: error?.message || String(error)
        }
      };
    }
  }

  if (PLATFORM === "win32") {
    try {
      const warmupMethod = await ensureWindowsClickHelperReady();
      return {
        status: 200,
        body: {
          ...payload,
          ok: true,
          clickHelper: {
            ok: true,
            source: "powershell-cached-csharp",
            script: path.basename(WINDOWS_CLICK_SCRIPT),
            csharp: path.basename(WINDOWS_CLICK_SOURCE),
            warmupMethod
          }
        }
      };
    } catch (error) {
      return {
        status: 503,
        body: {
          ...payload,
          ok: false,
          clickHelper: {
            ok: false,
            message: error?.message || String(error)
          },
          message: error?.message || String(error)
        }
      };
    }
  }

  return {
    status: supported ? 200 : 503,
    body: payload
  };
};

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin || "";

  if (origin && !origin.startsWith("chrome-extension://")) {
    json(res, 403, { ok: false, message: "只接受 Chrome 扩展页面请求。" }, origin);
    return;
  }

  if (req.method === "OPTIONS") {
    json(res, 204, {}, origin);
    return;
  }

  try {
    if (req.method === "GET" && req.url === "/health") {
      const health = await buildHealthPayload();
      json(res, health.status, health.body, origin);
      return;
    }

    if (req.method === "POST" && req.url === "/click-next") {
      await handleClickNext(req, res, origin);
      return;
    }

    if (req.method === "POST" && req.url === "/prepare-next") {
      await handlePrepareNext(req, res, origin);
      return;
    }

    if (req.method === "POST" && req.url === "/captcha-type") {
      await handleCaptchaType(req, res, origin);
      return;
    }

    json(res, 404, { ok: false, message: "not found" }, origin);
  } catch (error) {
    json(res, 500, { ok: false, message: error?.message || String(error) }, origin);
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Ticketlink native click backend listening at http://${HOST}:${PORT} (${PLATFORM})`);
  if (PLATFORM === "darwin") {
    getMacClickBinary()
      .then((helper) => {
        console.log(`macOS native click helper is ready (${helper.source}: ${path.basename(helper.binaryPath)}, ${helper.version}).`);
      })
      .catch((error) => {
        console.warn(`macOS native click helper unavailable; native mouse clicks will fail until the helper is available. ${error.message}`);
      });
  }
  if (PLATFORM === "win32") {
    ensureWindowsClickHelperReady()
      .then((method) => {
        console.log(`Windows native click helper is ready (${method}).`);
      })
      .catch((error) => {
        console.warn(`Windows native click helper warm-up failed; it will retry on demand. ${error.message}`);
      });
  }
});
