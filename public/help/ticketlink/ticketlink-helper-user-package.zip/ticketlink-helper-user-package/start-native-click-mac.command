#!/bin/bash
set -u

cd "$(dirname "$0")" || exit 1

NODE_MAJOR="${TICKETLINK_NODE_MAJOR:-22}"
LOCAL_NODE_DIR="$PWD/.ticketlink-node"
LOCAL_NODE_BIN="$LOCAL_NODE_DIR/bin/node"
RESOLVED_NODE_BIN=""
PORT="${TICKETLINK_CLICK_PORT:-19776}"
BACKEND_PID=""
MONITOR_PID=""
BACKEND_LOG_FILE=""

clear_quarantine_flags() {
  if command -v xattr >/dev/null 2>&1; then
    xattr -dr com.apple.quarantine "$PWD" >/dev/null 2>&1 || true
  fi
}

prepare_bundled_click_helpers() {
  local helper_path
  for helper_path in "$PWD/native-click-mac-arm64" "$PWD/native-click-mac-x64"; do
    if [ -f "$helper_path" ]; then
      chmod 755 "$helper_path" >/dev/null 2>&1 || true
    fi
  done
}

pause_before_exit() {
  echo
  read -n 1 -s -r -p "Press any key to close this window..."
  echo
}

health_check() {
  command -v curl >/dev/null 2>&1 &&
    curl --noproxy '*' -fsS -m 3 "http://127.0.0.1:${PORT}/health" >/dev/null 2>&1
}

run_with_timeout() {
  local seconds="$1"
  shift
  if command -v perl >/dev/null 2>&1; then
    perl -e 'alarm shift; exec @ARGV' "$seconds" "$@"
  else
    "$@"
  fi
}

write_diagnostic_report() {
  local reason="$1"
  local report_dir report_file tmp_click_bin

  report_dir="$PWD/tmp"
  mkdir -p "$report_dir"
  report_file="$report_dir/native-click-mac-diagnose-$(date +%Y%m%d-%H%M%S).txt"

  {
    echo "Ticketlink native click backend diagnostics"
    echo "Generated at: $(date)"
    echo "Reason: $reason"
    echo "Project: $PWD"
    echo "Expected backend: http://127.0.0.1:${PORT}"
    echo

    echo "==== macOS ===="
    sw_vers 2>&1 || true
    echo

    echo "==== CPU ===="
    uname -m 2>&1 || true
    echo

    echo "==== Node.js ===="
    if [ -n "${NODE_BIN:-}" ] && [ -x "$NODE_BIN" ]; then
      echo "Node: $NODE_BIN"
      "$NODE_BIN" -v 2>&1 || true
    elif command -v node >/dev/null 2>&1; then
      echo "Node: $(command -v node)"
      node -v 2>&1 || true
    else
      echo "Node.js not found."
    fi
    echo

    echo "==== Xcode / compiler ===="
    if command -v xcode-select >/dev/null 2>&1; then
      xcode-select -p 2>&1 || true
    else
      echo "xcode-select not found."
    fi
    if command -v clang >/dev/null 2>&1; then
      command -v clang
      clang --version 2>&1 | head -n 3
    else
      echo "clang not found. Install Xcode Command Line Tools: xcode-select --install"
    fi
    if command -v swiftc >/dev/null 2>&1; then
      command -v swiftc
      swiftc --version 2>&1 | head -n 3
    else
      echo "swiftc not found."
    fi
    echo

    echo "==== Bundled macOS click helpers ===="
    for helper in native-click-mac-arm64 native-click-mac-x64; do
      helper_path="$PWD/$helper"
      if [ -f "$helper_path" ]; then
        ls -l "$helper_path" 2>&1 || true
        file "$helper_path" 2>&1 || true
        if [ -x "$helper_path" ]; then
          echo "$helper: executable"
          "$helper_path" --version 2>&1 || true
        else
          echo "$helper: present but not executable"
        fi
      else
        echo "$helper: missing"
      fi
    done
    echo

    echo "==== Backend listener on port ${PORT} ===="
    lsof -nP -iTCP:"$PORT" -sTCP:LISTEN 2>&1 || true
    echo

    echo "==== Backend process ===="
    ps aux | grep '[n]ative-click-server.js' 2>&1 || true
    echo

    echo "==== Backend log ===="
    if [ -n "${BACKEND_LOG_FILE:-}" ] && [ -f "$BACKEND_LOG_FILE" ]; then
      tail -n 120 "$BACKEND_LOG_FILE" 2>&1 || true
    else
      echo "Backend log file not found."
    fi
    echo

    echo "==== Health check ===="
    if command -v curl >/dev/null 2>&1; then
      curl --noproxy '*' -v -m 5 "http://127.0.0.1:${PORT}/health" 2>&1 || true
    else
      echo "curl not found."
    fi
    echo

    echo "==== Local socket check ===="
    if command -v nc >/dev/null 2>&1; then
      nc -vz 127.0.0.1 "$PORT" 2>&1 || true
    else
      echo "nc not found."
    fi
    echo

    echo "==== macOS click helper runtime check ===="
    arch_name="$(uname -m 2>/dev/null || true)"
    bundled_helper=""
    case "$arch_name" in
      arm64) bundled_helper="$PWD/native-click-mac-arm64" ;;
      x86_64) bundled_helper="$PWD/native-click-mac-x64" ;;
    esac
    if [ -n "$bundled_helper" ] && [ -x "$bundled_helper" ]; then
      run_with_timeout 5 "$bundled_helper" --version 2>&1
      echo "[helper exit=$?]"
    elif command -v clang >/dev/null 2>&1 && [ -f "$PWD/native-click-mac.c" ]; then
      min_version="11.0"
      if [ "$arch_name" = "x86_64" ]; then
        min_version="10.15"
      fi
      tmp_click_bin="${TMPDIR:-/tmp}/ticketlink-diagnose-click-$$"
      run_with_timeout 20 clang "$PWD/native-click-mac.c" -O2 "-mmacosx-version-min=${min_version}" -framework ApplicationServices -o "$tmp_click_bin" 2>&1
      compile_exit=$?
      echo "[clang exit=$compile_exit]"
      if [ "$compile_exit" -eq 0 ]; then
        run_with_timeout 5 "$tmp_click_bin" --version 2>&1
        echo "[compiled helper exit=$?]"
      fi
      rm -f "$tmp_click_bin"
    else
      echo "Skipped because bundled helper is missing and clang/native-click-mac.c is unavailable."
    fi
    echo

    echo "==== Apple Events / Accessibility quick check ===="
    osascript -e 'tell application "System Events" to get name of first process' 2>&1 | head -n 5 || true
    echo

    echo "==== Proxy environment ===="
    env | grep -i '_proxy=' || true
    echo

    echo "==== Interpretation ===="
    echo "If lsof has no LISTEN line, the backend is not actually listening on 127.0.0.1:${PORT}."
    echo "If curl fails but lsof shows node listening, check the clickHelper message in the health check output."
    echo "A bundled helper must print native-click-mac-cgevent-hid when run with --version."
    echo "If the bundled helper is missing and clang compile fails, install Xcode Command Line Tools or use a complete backend zip."
    echo "If osascript fails, grant Terminal/iTerm Accessibility permission."
    echo "Report saved to: $report_file"
  } 2>&1 | tee "$report_file"

  echo
  echo "Diagnostic report saved:"
  echo "$report_file"
}

stop_background_jobs() {
  if [ -n "${MONITOR_PID:-}" ] && kill -0 "$MONITOR_PID" >/dev/null 2>&1; then
    kill "$MONITOR_PID" >/dev/null 2>&1 || true
  fi
  if [ -n "${BACKEND_PID:-}" ] && kill -0 "$BACKEND_PID" >/dev/null 2>&1; then
    kill "$BACKEND_PID" >/dev/null 2>&1 || true
  fi
}

detect_node_platform() {
  case "$(uname -m)" in
    arm64)
      echo "darwin-arm64"
      ;;
    x86_64)
      echo "darwin-x64"
      ;;
    *)
      echo ""
      ;;
  esac
}

download_local_node() {
  local platform archive shasums_url archive_url tmp_dir shasums_file expected_sha actual_sha extracted_dir

  platform="$(detect_node_platform)"
  if [ -z "$platform" ]; then
    echo "Unsupported Mac CPU: $(uname -m)"
    return 1
  fi

  if ! command -v curl >/dev/null 2>&1; then
    echo "curl is missing. Please install Node.js manually from https://nodejs.org/"
    return 1
  fi

  if ! command -v tar >/dev/null 2>&1; then
    echo "tar is missing. Please install Node.js manually from https://nodejs.org/"
    return 1
  fi

  tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/ticketlink-node.XXXXXX")" || return 1
  shasums_url="https://nodejs.org/dist/latest-v${NODE_MAJOR}.x/SHASUMS256.txt"
  shasums_file="$tmp_dir/SHASUMS256.txt"

  echo "Node.js was not found on this Mac."
  echo "Downloading a private Node.js runtime for Ticketlink..."
  echo "Source: https://nodejs.org/dist/latest-v${NODE_MAJOR}.x/"
  echo

  if ! curl -fL --connect-timeout 20 --retry 2 "$shasums_url" -o "$shasums_file"; then
    echo "Failed to download Node.js version list."
    rm -rf "$tmp_dir"
    return 1
  fi

  archive="$(grep "node-v.*-${platform}.tar.gz$" "$shasums_file" | awk '{print $2}' | head -n 1)"
  if [ -z "$archive" ]; then
    echo "Failed to find a Node.js package for $platform."
    rm -rf "$tmp_dir"
    return 1
  fi

  archive_url="https://nodejs.org/dist/latest-v${NODE_MAJOR}.x/$archive"
  if ! curl -fL --connect-timeout 20 --retry 2 "$archive_url" -o "$tmp_dir/$archive"; then
    echo "Failed to download $archive."
    rm -rf "$tmp_dir"
    return 1
  fi

  if command -v shasum >/dev/null 2>&1; then
    expected_sha="$(grep " $archive$" "$shasums_file" | awk '{print $1}')"
    actual_sha="$(shasum -a 256 "$tmp_dir/$archive" | awk '{print $1}')"
    if [ -n "$expected_sha" ] && [ "$expected_sha" != "$actual_sha" ]; then
      echo "Downloaded Node.js package checksum did not match. Please try again."
      rm -rf "$tmp_dir"
      return 1
    fi
  fi

  if ! tar -xzf "$tmp_dir/$archive" -C "$tmp_dir"; then
    echo "Failed to extract Node.js package."
    rm -rf "$tmp_dir"
    return 1
  fi

  extracted_dir="$tmp_dir/${archive%.tar.gz}"
  if [ ! -x "$extracted_dir/bin/node" ]; then
    echo "Downloaded Node.js package is incomplete."
    rm -rf "$tmp_dir"
    return 1
  fi

  rm -rf "$LOCAL_NODE_DIR"
  mv "$extracted_dir" "$LOCAL_NODE_DIR"
  rm -rf "$tmp_dir"
  echo "Node.js is ready: $("$LOCAL_NODE_BIN" -v)"
  echo
  return 0
}

resolve_node() {
  if [ -x "$LOCAL_NODE_BIN" ]; then
    RESOLVED_NODE_BIN="$LOCAL_NODE_BIN"
    return 0
  fi

  if command -v node >/dev/null 2>&1; then
    RESOLVED_NODE_BIN="$(command -v node)"
    return 0
  fi

  if download_local_node; then
    RESOLVED_NODE_BIN="$LOCAL_NODE_BIN"
    return 0
  fi

  return 1
}

clear_quarantine_flags
prepare_bundled_click_helpers

if ! resolve_node; then
  RESOLVED_NODE_BIN=""
fi

NODE_BIN="$RESOLVED_NODE_BIN"
if [ -z "$NODE_BIN" ] || [ ! -x "$NODE_BIN" ]; then
  echo
  echo "Could not prepare Node.js automatically."
  echo "Please install Node.js LTS manually from https://nodejs.org/ and double-click this file again."
  open "https://nodejs.org/" >/dev/null 2>&1 || true
  pause_before_exit
  exit 1
fi

echo "Starting Ticketlink native click backend..."
echo "Node: $("$NODE_BIN" -v)"
echo "Backend: http://127.0.0.1:${PORT}"
echo "Keep this window open while using the Chrome extension."
echo

mkdir -p "$PWD/tmp"
BACKEND_LOG_FILE="$PWD/tmp/native-click-backend.log"
: > "$BACKEND_LOG_FILE"
SERVER_ENTRY="$PWD/native-click-server.js"
(
  cd / || exit 1
  "$NODE_BIN" "$SERVER_ENTRY"
) > "$BACKEND_LOG_FILE" 2>&1 &
BACKEND_PID=$!

trap 'stop_background_jobs; exit 130' INT TERM

sleep 1
if health_check; then
  echo "Backend health check: OK"
else
  echo "Backend health check: FAILED"
  if [ -s "$BACKEND_LOG_FILE" ]; then
    echo
    echo "Backend startup log:"
    tail -n 80 "$BACKEND_LOG_FILE" 2>&1 || true
    echo
  fi
  echo "A diagnostic report will be generated automatically."
  write_diagnostic_report "startup_health_check_failed"
fi

(
  report_written=0
  while kill -0 "$BACKEND_PID" >/dev/null 2>&1; do
    sleep 5
    if ! health_check; then
      echo
      echo "Backend health check failed while the backend window is still open."
      if [ "$report_written" -eq 0 ]; then
        report_written=1
        write_diagnostic_report "runtime_health_check_failed"
      fi
    fi
  done
) &
MONITOR_PID=$!

wait "$BACKEND_PID"
BACKEND_EXIT=$?

if [ -n "${MONITOR_PID:-}" ] && kill -0 "$MONITOR_PID" >/dev/null 2>&1; then
  kill "$MONITOR_PID" >/dev/null 2>&1 || true
fi

echo
echo "Ticketlink native click backend stopped. Exit code: $BACKEND_EXIT"
if [ "$BACKEND_EXIT" -ne 0 ]; then
  if [ -s "$BACKEND_LOG_FILE" ]; then
    echo
    echo "Backend exit log:"
    tail -n 80 "$BACKEND_LOG_FILE" 2>&1 || true
  fi
  write_diagnostic_report "backend_process_exited_${BACKEND_EXIT}"
fi
pause_before_exit
