@echo off
setlocal
cd /d "%~dp0"

set "NODE_EXE=%CD%\.ticketlink-node\node.exe"

if exist "%NODE_EXE%" goto start_backend

where node >nul 2>nul
if not errorlevel 1 (
  for /f "delims=" %%I in ('where node 2^>nul') do (
    set "NODE_EXE=%%I"
    goto start_backend
  )
)

echo Node.js is not installed or not available in PATH.
echo Downloading a private Node.js runtime for Ticketlink...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0prepare-node-windows.ps1"
if errorlevel 1 (
  echo.
  echo Could not prepare Node.js automatically.
  echo Please install Node.js LTS from https://nodejs.org/ and then run this file again.
  start "" "https://nodejs.org/"
  pause
  exit /b 1
)

if not exist "%NODE_EXE%" (
  echo.
  echo Node.js download finished, but node.exe was not found.
  echo Please install Node.js LTS from https://nodejs.org/ and then run this file again.
  start "" "https://nodejs.org/"
  pause
  exit /b 1
)

:start_backend
echo Starting Ticketlink native click backend...
"%NODE_EXE%" -v
echo Backend: http://127.0.0.1:19776
echo Keep this window open while using the Chrome extension.
echo.

"%NODE_EXE%" native-click-server.js

echo.
echo Ticketlink native click backend stopped.
pause
