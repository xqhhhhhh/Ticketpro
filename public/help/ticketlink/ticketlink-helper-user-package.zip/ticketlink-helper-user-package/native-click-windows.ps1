param(
  [Parameter(Mandatory = $false, Position = 0)]
  [Nullable[int]]$X,

  [Parameter(Mandatory = $false, Position = 1)]
  [Nullable[int]]$Y,

  [Parameter(Mandatory = $false, Position = 2)]
  [Nullable[int]]$StartX,

  [Parameter(Mandatory = $false, Position = 3)]
  [Nullable[int]]$StartY,

  [Parameter(Mandatory = $false, Position = 4)]
  [Nullable[int]]$HoverSettleMs,

  [Parameter(Mandatory = $false, Position = 5)]
  [Nullable[int]]$ClickHoldMs,

  [Parameter(Mandatory = $false, Position = 6)]
  [Nullable[int]]$PreDownSettleMs,

  [Parameter(Mandatory = $false, Position = 7)]
  [Nullable[int]]$AfterUpSettleMs,

  [Parameter(Mandatory = $false, Position = 8)]
  [Nullable[int]]$TrajectoryDurationMs,

  [Parameter(Mandatory = $false)]
  [switch]$MoveOnly,

  [Parameter(Mandatory = $false)]
  [switch]$Instant,

  [Parameter(Mandatory = $false)]
  [switch]$Warmup,

  [Parameter(Mandatory = $false)]
  [string]$GeometryJson,

  [ValidateSet("inspect", "clear", "type")]
  [string]$KeyboardAction,

  [string]$Text,

  [long]$ExpectedWindow = 0,

  [long]$ExpectedFocus = 0,

  [int]$KeyDelayMs = 120,

  [int]$KeyJitterMs = 0
)

$ErrorActionPreference = "Stop"
try {
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [Console]::OutputEncoding = $utf8NoBom
  $OutputEncoding = $utf8NoBom
} catch {}

# MoveOnly does not compile the C# helper. This keeps cursor warm-up fast and
# compatible with Windows PowerShell 5.1 and stricter endpoint security tools.
if ($MoveOnly -and -not $GeometryJson) {
  try {
    if ($null -eq $X -or $null -eq $Y) {
      throw "X and Y are required for cursor movement."
    }
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
    $point = New-Object System.Drawing.Point -ArgumentList $X, $Y
    [System.Windows.Forms.Cursor]::Position = $point
    Write-Output "windows-forms-cursor-move"
    exit 0
  } catch {
    $message = $_.Exception.Message
    if ($_.Exception.InnerException -and $_.Exception.InnerException.Message) {
      $message = $_.Exception.InnerException.Message
    }
    [Console]::Error.WriteLine("windows-cursor-move failed: $message")
    exit 1
  }
}

try {
  $sourcePath = Join-Path -Path $PSScriptRoot -ChildPath "native-click-windows.cs"
  if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
    throw "Missing native-click-windows.cs next to native-click-windows.ps1."
  }

  $sourceHash = (Get-FileHash -LiteralPath $sourcePath -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
  $cacheDirectory = Join-Path -Path ([System.IO.Path]::GetTempPath()) -ChildPath "ticketlink-native-click"
  $assemblyPath = Join-Path -Path $cacheDirectory -ChildPath ("ticketlink-native-click-" + $sourceHash + ".dll")
  New-Item -ItemType Directory -Path $cacheDirectory -Force -ErrorAction Stop | Out-Null

  $loadedFromCache = $false
  if (Test-Path -LiteralPath $assemblyPath -PathType Leaf) {
    try {
      Add-Type -Path $assemblyPath -ErrorAction Stop
      $loadedFromCache = $true
    } catch {
      Remove-Item -LiteralPath $assemblyPath -Force -ErrorAction SilentlyContinue
    }
  }

  if (-not $loadedFromCache) {
    try {
      Add-Type -Path $sourcePath -OutputAssembly $assemblyPath -PassThru -ErrorAction Stop | Out-Null
    } catch {
      # Another process may have completed the same cache entry first.
      if (Test-Path -LiteralPath $assemblyPath -PathType Leaf) {
        Add-Type -Path $assemblyPath -ErrorAction Stop
        $loadedFromCache = $true
      } else {
        throw
      }
    }
  }

  if ($Warmup) {
    if ($loadedFromCache) {
      Write-Output "windows-user32-helper-cache-hit"
    } else {
      Write-Output "windows-user32-helper-cache-created"
    }
    exit 0
  }

  if ($KeyboardAction) {
    $result = [TicketlinkNativeKeyboard]::Execute(
      $KeyboardAction, $Text, $ExpectedWindow, $ExpectedFocus, $KeyDelayMs, $KeyJitterMs
    )
    $result | ConvertTo-Json -Depth 4 -Compress
    exit 0
  }

  if ($null -eq $X -or $null -eq $Y) {
    throw "X and Y are required for mouse clicks."
  }

  $geometry = $null
  $logicalX = $X
  $logicalY = $Y
  if ($GeometryJson) {
    $requestGeometry = $GeometryJson | ConvertFrom-Json -ErrorAction Stop
    $metrics = $requestGeometry.windowMetrics
    foreach ($metricName in @("screenX", "screenY", "outerWidth", "outerHeight")) {
      if ($null -eq $metrics.$metricName) { throw "Missing browser window metric: $metricName" }
    }
    if ($null -eq $requestGeometry.expectedDisplayScale) { throw "Missing browser display scale." }
    $geometry = [TicketlinkNativeClick]::ConfigureBrowserGeometry(
      [double]$metrics.screenX, [double]$metrics.screenY,
      [double]$metrics.outerWidth, [double]$metrics.outerHeight,
      [double]$requestGeometry.expectedDisplayScale
    )
    $X = $geometry.ToPhysicalX([double]$logicalX)
    $Y = $geometry.ToPhysicalY([double]$logicalY)
    $geometry.VerifyTarget([int]$X, [int]$Y)
    if ($null -ne $StartX -and $null -ne $StartY) {
      $StartX = $geometry.ToPhysicalX([double]$StartX)
      $StartY = $geometry.ToPhysicalY([double]$StartY)
    }
  }

  if ($MoveOnly) {
    $method = [TicketlinkNativeClick]::Move([int]$X, [int]$Y)
    @{ method = $method; x = [int]$X; y = [int]$Y; coordinateDiagnostics = $geometry } | ConvertTo-Json -Depth 4 -Compress
    exit 0
  }

  $resolvedHoverSettleMs = 260
  if ($null -ne $HoverSettleMs) {
    $resolvedHoverSettleMs = [int]$HoverSettleMs
  }
  $resolvedClickHoldMs = 220
  if ($null -ne $ClickHoldMs) {
    $resolvedClickHoldMs = [int]$ClickHoldMs
  }
  $resolvedPreDownSettleMs = 100
  if ($null -ne $PreDownSettleMs) {
    $resolvedPreDownSettleMs = [int]$PreDownSettleMs
  }
  $resolvedAfterUpSettleMs = 120
  if ($null -ne $AfterUpSettleMs) {
    $resolvedAfterUpSettleMs = [int]$AfterUpSettleMs
  }
  $resolvedTrajectoryDurationMs = 252
  if ($null -ne $TrajectoryDurationMs) {
    $resolvedTrajectoryDurationMs = [int]$TrajectoryDurationMs
  }

  if ($Instant) {
    $method = [TicketlinkNativeClick]::ClickInstant(
      $X,
      $Y,
      $resolvedClickHoldMs,
      $resolvedAfterUpSettleMs
    )
  } else {
    $method = [TicketlinkNativeClick]::Click(
      $X,
      $Y,
      $StartX,
      $StartY,
      $resolvedHoverSettleMs,
      $resolvedClickHoldMs,
      $resolvedPreDownSettleMs,
      $resolvedAfterUpSettleMs,
      $resolvedTrajectoryDurationMs
    )
  }
  if ($geometry) {
    @{ method = $method; x = [int]$X; y = [int]$Y; logicalX = [int]$logicalX; logicalY = [int]$logicalY; hoverStart = @{ x = $StartX; y = $StartY; coordinateSpace = "physical" }; coordinateDiagnostics = $geometry } | ConvertTo-Json -Depth 4 -Compress
  } else {
    Write-Output $method
  }
} catch {
  $message = $_.Exception.Message
  if ($_.Exception.InnerException -and $_.Exception.InnerException.Message) {
    $message = $_.Exception.InnerException.Message
  }
  [Console]::Error.WriteLine("windows-user32-click failed: $message")
  exit 1
}
