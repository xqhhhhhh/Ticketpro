$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$nodeMajor = if ($env:TICKETLINK_NODE_MAJOR) { [int]$env:TICKETLINK_NODE_MAJOR } else { 22 }
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$localNodeDir = Join-Path $root ".ticketlink-node"
$localNodeExe = Join-Path $localNodeDir "node.exe"

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if (Test-Path $localNodeExe) {
  Write-Host "Node.js is already ready: $(& $localNodeExe -v)"
  exit 0
}

$processorArch = [string]$env:PROCESSOR_ARCHITECTURE
$processorArchW6432 = [string]$env:PROCESSOR_ARCHITEW6432
$archProbe = "$processorArch $processorArchW6432".ToUpperInvariant()

if ($archProbe -match "ARM64") {
  $platform = "win-arm64"
} elseif ($archProbe -match "AMD64|X64") {
  $platform = "win-x64"
} else {
  throw "Unsupported Windows CPU architecture: $processorArch"
}

$baseUrl = "https://nodejs.org/dist/latest-v$nodeMajor.x"
$tmpRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("ticketlink-node-" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $tmpRoot | Out-Null

try {
  $shasumsUrl = "$baseUrl/SHASUMS256.txt"
  $shasumsPath = Join-Path $tmpRoot "SHASUMS256.txt"
  Write-Host "Step 1/3: downloading Node.js package list..."
  Invoke-WebRequest -Uri $shasumsUrl -OutFile $shasumsPath -UseBasicParsing

  $line = Get-Content $shasumsPath | Where-Object { $_ -match "node-v.*-$platform\.zip$" } | Select-Object -First 1
  if (-not $line) {
    throw "Could not find a Node.js package for $platform at $baseUrl"
  }

  $parts = $line -split "\s+"
  $expectedHash = $parts[0].Trim().ToLowerInvariant()
  $archiveName = $parts[1].Trim()
  $archiveUrl = "$baseUrl/$archiveName"
  $archivePath = Join-Path $tmpRoot $archiveName

  Write-Host "Step 2/3: downloading $archiveName..."
  Write-Host "This may take a few minutes on the first run. Please do not close this window."
  Invoke-WebRequest -Uri $archiveUrl -OutFile $archivePath -UseBasicParsing

  $actualHash = (Get-FileHash -Algorithm SHA256 -Path $archivePath).Hash.ToLowerInvariant()
  if ($expectedHash -and $actualHash -ne $expectedHash) {
    throw "Downloaded Node.js package checksum did not match."
  }

  Write-Host "Step 3/3: extracting Node.js..."
  Expand-Archive -Path $archivePath -DestinationPath $tmpRoot -Force

  $extractedName = [System.IO.Path]::GetFileNameWithoutExtension($archiveName)
  $extractedDir = Join-Path $tmpRoot $extractedName
  $extractedNodeExe = Join-Path $extractedDir "node.exe"
  if (-not (Test-Path $extractedNodeExe)) {
    throw "Downloaded Node.js package is incomplete."
  }

  if (Test-Path $localNodeDir) {
    Remove-Item -Recurse -Force $localNodeDir
  }
  Move-Item -Path $extractedDir -Destination $localNodeDir

  Write-Host "Node.js is ready: $(& $localNodeExe -v)"
  exit 0
} finally {
  if (Test-Path $tmpRoot) {
    Remove-Item -Recurse -Force $tmpRoot -ErrorAction SilentlyContinue
  }
}
